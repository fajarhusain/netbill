<?php

use App\Http\Middleware\EnsureRole;
use App\Http\Middleware\EnsureUserActive;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->trustProxies(at: '*');

        $middleware->alias([
            'role' => EnsureRole::class,
            'active' => EnsureUserActive::class,
        ]);

        $middleware->appendToGroup('web', EnsureUserActive::class);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
