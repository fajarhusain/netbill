<?php $__env->startSection('title', 'Daftar Tagihan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <h4 class="mb-0"><i class="bi bi-file-text"></i> Daftar Tagihan</h4>
    <a href="<?php echo e(route('invoices.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Buat Tagihan</a>
</div>

<div class="card mb-3"><div class="card-body">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-12 col-md-4">
        <label class="form-label small">Cari Pelanggan</label>
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Nama / kode">
    </div>
    <div class="col-6 col-md-3">
        <label class="form-label small">Periode</label>
        <input type="month" name="period" value="<?php echo e(request('period')); ?>" class="form-control">
    </div>
    <div class="col-6 col-md-3">
        <label class="form-label small">Status</label>
        <select name="status" class="form-select">
            <option value="">Semua</option>
            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s->value); ?>" <?php if(request('status')===$s->value): echo 'selected'; endif; ?>><?php echo e($s->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-12 col-md-2 d-flex gap-1">
        <button class="btn btn-outline-primary flex-grow-1"><i class="bi bi-search"></i></button>
        <a href="<?php echo e(route('invoices.index', ['arrears' => 1])); ?>" class="btn btn-outline-danger" title="Tunggakan"><i class="bi bi-exclamation-triangle"></i></a>
    </div>
</form>
</div></div>

<div class="card">
<div class="table-responsive">
<table class="table table-hover align-middle mb-0">
<thead class="table-light"><tr><th>No. Tagihan</th><th>Pelanggan</th><th>Periode</th><th>Nominal</th><th>Sisa</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td><?php echo e($inv->invoice_number); ?></td>
    <td><?php echo e($inv->customer->name); ?><div class="small text-muted"><?php echo e($inv->customer->customer_code); ?></div></td>
    <td><?php echo e(format_period($inv->billing_period)); ?></td>
    <td><?php echo e(format_rupiah($inv->amount)); ?></td>
    <td class="<?php echo e($inv->balance() > 0 ? 'text-danger' : ''); ?>"><?php echo e(format_rupiah($inv->balance())); ?></td>
    <td><span class="badge <?php echo e($inv->status->badgeClass()); ?>"><?php echo e($inv->status->label()); ?></span></td>
    <td class="text-end"><a href="<?php echo e(route('invoices.show', $inv)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="7" class="text-center text-muted py-4">Belum ada tagihan.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<?php if($invoices->hasPages()): ?><div class="card-footer bg-white"><?php echo e($invoices->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/invoices/index.blade.php ENDPATH**/ ?>