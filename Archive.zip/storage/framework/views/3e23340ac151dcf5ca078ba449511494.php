<?php $__env->startSection('title', 'Riwayat Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-cash-stack"></i> <?php echo e(auth()->user()->isAdmin() ? 'Transaksi' : 'Riwayat Transaksi'); ?></h5>
</div>

<div class="card mb-3"><div class="card-body py-3">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-12 col-md-3">
        <label class="form-label small mb-1">Cari</label>
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="No. transaksi / pelanggan">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small mb-1">Dari</label>
        <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="form-control">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small mb-1">Sampai</label>
        <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="form-control">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small mb-1">Metode</label>
        <select name="method" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($m->value); ?>" <?php if(request('method')===$m->value): echo 'selected'; endif; ?>><?php echo e($m->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small mb-1">Status</label>
        <select name="status" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s->value); ?>" <?php if(request('status')===$s->value): echo 'selected'; endif; ?>><?php echo e($s->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <?php if(auth()->user()->isAdmin() && $collectors->isNotEmpty()): ?>
    <div class="col-6 col-md-3">
        <label class="form-label small mb-1">Petugas</label>
        <select name="collector_id" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $collectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(request('collector_id')==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <?php endif; ?>
    <div class="col-12 col-md-1 d-grid"><button class="btn btn-outline-primary btn-touch"><i class="bi bi-search"></i></button></div>
</form>
</div></div>

<?php
    $colors = ['#0d6efd','#6610f2','#0dcaf0','#198754','#fd7e14','#dc3545','#d63384','#6f42c1'];
?>

<?php if($payments->isEmpty()): ?>
    <div class="card"><div class="card-body text-center text-muted py-5">
        <i class="bi bi-receipt-cutoff fs-1 d-block mb-2 opacity-50"></i>
        Belum ada transaksi.
    </div></div>
<?php else: ?>
    <div class="d-md-none">
        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('payments.show', $p)); ?>" class="nb-list-card">
            <div class="nb-avatar" style="background:<?php echo e($colors[ord(mb_strtoupper(mb_substr($p->customer->name,0,1))) % count($colors)]); ?>"><?php echo e(mb_strtoupper(mb_substr($p->customer->name,0,1))); ?></div>
            <div class="nb-body">
                <p class="nb-title"><?php echo e($p->customer->name); ?></p>
                <p class="nb-sub"><?php echo e($p->transaction_number); ?> · <?php echo e(format_datetime($p->paid_at)); ?></p>
            </div>
            <div class="nb-end">
                <div class="fw-bold text-success"><?php echo e(format_rupiah($p->amount_received)); ?></div>
                <span class="badge <?php echo e($p->status->badgeClass()); ?>"><?php echo e($p->status->label()); ?></span>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card d-none d-md-block">
        <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>No. Transaksi</th><th>Pelanggan</th><th>Nominal</th><th>Metode</th><th>Petugas</th><th>Waktu</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><strong><?php echo e($p->transaction_number); ?></strong></td>
                <td><?php echo e($p->customer->name); ?><div class="small text-muted"><?php echo e($p->customer->customer_code); ?></div></td>
                <td><?php echo e(format_rupiah($p->amount_received)); ?></td>
                <td><?php echo e($p->payment_method->label()); ?></td>
                <td><?php echo e($p->collector->name); ?></td>
                <td class="small"><?php echo e(format_datetime($p->paid_at)); ?></td>
                <td><span class="badge <?php echo e($p->status->badgeClass()); ?>"><?php echo e($p->status->label()); ?></span></td>
                <td class="text-end text-nowrap">
                    <a href="<?php echo e(route('payments.show', $p)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
                    <a href="<?php echo e(route('payments.receipt', $p)); ?>" class="btn btn-sm btn-outline-primary" title="Bukti"><i class="bi bi-receipt"></i></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php endif; ?>

<?php if($payments->hasPages()): ?>
<div class="d-flex justify-content-center mt-3"><?php echo e($payments->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/payments/index.blade.php ENDPATH**/ ?>