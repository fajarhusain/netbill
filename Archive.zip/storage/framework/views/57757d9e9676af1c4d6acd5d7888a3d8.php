<?php $__env->startSection('title', 'Kunjungan Penagihan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-geo-alt"></i> Kunjungan</h5>
    <a href="<?php echo e(route('visits.create')); ?>" class="btn btn-primary btn-touch"><i class="bi bi-plus-lg"></i> Catat</a>
</div>

<div class="card mb-3"><div class="card-body py-3">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-12 col-md-4"><label class="form-label small mb-1">Cari Pelanggan</label><input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"></div>
    <div class="col-6 col-md-3"><label class="form-label small mb-1">Hasil</label><select name="result" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($r->value); ?>" <?php if(request('result')===$r->value): echo 'selected'; endif; ?>><?php echo e($r->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <?php if(auth()->user()->isAdmin() && $collectors->isNotEmpty()): ?><div class="col-6 col-md-3"><label class="form-label small mb-1">Petugas</label><select name="collector_id" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $collectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(request('collector_id')==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div><?php endif; ?>
    <div class="col-12 col-md-2 d-grid"><button class="btn btn-outline-primary btn-touch"><i class="bi bi-search"></i> Filter</button></div>
</form>
</div></div>

<?php
    $resultIcons = ['paid'=>'check-circle text-success','not_home'=>'door-closed text-warning','recall_requested'=>'arrow-repeat text-info','cannot_pay'=>'cash-coin text-warning','address_not_found'=>'exclamation-circle text-danger','other'=>'question-circle text-muted'];
?>

<?php if($visits->isEmpty()): ?>
    <div class="card"><div class="card-body text-center text-muted py-5">
        <i class="bi bi-geo-alt fs-1 d-block mb-2 opacity-50"></i>
        Belum ada kunjungan.
    </div></div>
<?php else: ?>
    <div class="d-md-none">
        <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('visits.show', $v)); ?>" class="nb-list-card">
            <div class="nb-avatar" style="background:#6c757d;"><i class="bi bi-<?php echo e($resultIcons[$v->result->value] ?? 'geo-alt'); ?>"></i></div>
            <div class="nb-body">
                <p class="nb-title"><?php echo e($v->customer->name); ?></p>
                <p class="nb-sub"><?php echo e(format_datetime($v->visited_at)); ?></p>
            </div>
            <div class="nb-end">
                <span class="small text-muted"><?php echo e($v->result->label()); ?></span>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card d-none d-md-block">
        <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Waktu</th><th>Pelanggan</th><th>Petugas</th><th>Hasil</th><th>Catatan</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="small"><?php echo e(format_datetime($v->visited_at)); ?></td>
                <td><?php echo e($v->customer->name); ?><div class="small text-muted"><?php echo e($v->customer->customer_code); ?></div></td>
                <td><?php echo e($v->collector->name); ?></td>
                <td><?php echo e($v->result->label()); ?></td>
                <td class="small"><?php echo e(Illuminate\Support\Str::limit($v->notes, 40)); ?></td>
                <td class="text-end"><a href="<?php echo e(route('visits.show', $v)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php endif; ?>

<?php if($visits->hasPages()): ?>
<div class="d-flex justify-content-center mt-3"><?php echo e($visits->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/visits/index.blade.php ENDPATH**/ ?>