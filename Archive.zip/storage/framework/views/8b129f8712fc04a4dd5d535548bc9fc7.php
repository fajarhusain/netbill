<?php $__env->startSection('title', $customer->name); ?>

<?php
    $waPhone = preg_replace('/[^0-9]/', '', $customer->phone ?? '');
    if (str_starts_with($waPhone, '0')) { $waPhone = '62' . substr($waPhone, 1); }
    $initial = mb_strtoupper(mb_substr($customer->name, 0, 1));
?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center mb-3 gap-2">
    <a href="<?php echo e(route('scan.index')); ?>" class="btn btn-outline-secondary btn-touch text-nowrap"><i class="bi bi-arrow-left"></i> <span class="d-none d-sm-inline">Scan Ulang</span></a>
    <div class="flex-grow-1 min-w-0">
        <h5 class="mb-0 text-truncate"><?php echo e($customer->name); ?></h5>
        <div class="small text-muted d-flex align-items-center gap-2 flex-wrap">
            <span><?php echo e($customer->customer_code); ?></span>
            <span class="badge <?php echo e($customer->status->badgeClass()); ?>"><?php echo e($customer->status->label()); ?></span>
        </div>
    </div>
</div>

<?php if(session('warning')): ?>
<div class="alert alert-warning"><i class="bi bi-exclamation-triangle"></i> <?php echo e(session('warning')); ?></div>
<?php endif; ?>

<?php
    $avatarColors = ['#0d6efd','#6610f2','#0dcaf0','#198754','#fd7e14','#dc3545','#d63384','#6f42c1'];
    $colorIdx = ord($initial) % count($avatarColors);
?>

<div class="card mb-3">
    <div class="card-body">
        <div class="d-flex align-items-center mb-3">
            <div class="nb-avatar" style="width:56px;height:56px;background:<?php echo e($avatarColors[$colorIdx]); ?>;font-size:1.4rem;margin-right:.85rem;"><?php echo e($initial); ?></div>
            <div class="min-w-0">
                <div class="fw-bold fs-5 text-truncate"><?php echo e($customer->name); ?></div>
                <div class="small text-muted"><?php echo e($customer->package?->name ?? '-'); ?> · <?php echo e(format_rupiah($customer->monthly_fee)); ?>/bln</div>
            </div>
        </div>

        <div class="row g-2 small">
            <div class="col-12">
                <i class="bi bi-geo-alt text-muted me-1"></i> <?php echo e($customer->address ?: 'Alamat belum diisi'); ?>

            </div>
            <div class="col-12 d-flex align-items-center justify-content-between">
                <span><i class="bi bi-whatsapp text-muted me-1"></i> <?php echo e($customer->phone ?: '-'); ?></span>
                <?php if($waPhone): ?>
                <a href="https://wa.me/<?php echo e($waPhone); ?>?text=Halo%20<?php echo e(urlencode($customer->name)); ?>%2C%20ini%20petugas%20penagihan%20RT%2FRW%20Net." target="_blank" class="btn btn-sm btn-success btn-touch"><i class="bi bi-chat-dots"></i> Hubungi</a>
                <?php endif; ?>
            </div>
        </div>

        <?php if($customer->notes): ?>
        <div class="alert alert-info small mt-2 mb-0"><i class="bi bi-info-circle"></i> <?php echo e($customer->notes); ?></div>
        <?php endif; ?>
    </div>
</div>

<div class="card mb-3 <?php if($totalArrears > 0): ?> bg-danger text-white <?php else: ?> bg-success text-white <?php endif; ?>">
    <div class="card-body text-center py-3">
        <div class="small opacity-75">Total Tunggakan</div>
        <div class="fs-3 fw-bold"><?php echo e(format_rupiah($totalArrears)); ?></div>
        <?php if($totalArrears == 0): ?>
        <div class="small"><i class="bi bi-check-circle"></i> Pelanggan lunas</div>
        <?php endif; ?>
    </div>
</div>

<?php if($arrears->isNotEmpty()): ?>
<a href="<?php echo e(route('scan.pay.form', $customer)); ?>" class="btn btn-success btn-lg btn-touch w-100 mb-3 fw-bold">
    <i class="bi bi-cash-coin"></i> Terima Pembayaran
</a>
<?php else: ?>
<span class="btn btn-success btn-lg w-100 mb-3 disabled">Tidak ada tunggakan</span>
<?php endif; ?>

<div class="d-flex gap-2 mb-3">
    <a href="<?php echo e(route('visits.create')); ?>?customer_id=<?php echo e($customer->id); ?>" class="btn btn-outline-secondary btn-touch flex-fill"><i class="bi bi-geo-alt"></i> Catat Kunjungan</a>
</div>

<h6 class="mb-2"><i class="bi bi-file-text"></i> Tagihan Belum Lunas</h6>
<?php if($arrears->isEmpty()): ?>
    <div class="card mb-3"><div class="card-body text-center text-muted small py-3">Tidak ada tunggakan.</div></div>
<?php else: ?>
    <div class="d-md-none">
    <?php $__currentLoopData = $arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="nb-list-card">
            <div class="nb-body">
                <p class="nb-title"><?php echo e(format_period($inv->billing_period)); ?></p>
                <p class="nb-sub">Sisa: <span class="text-danger fw-semibold"><?php echo e(format_rupiah($inv->balance())); ?></span></p>
            </div>
            <div class="nb-end">
                <span class="badge <?php echo e($inv->status->badgeClass()); ?>"><?php echo e($inv->status->label()); ?></span>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="card d-none d-md-block">
        <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
            <thead class="table-light"><tr><th>Periode</th><th>Nominal</th><th>Dibayar</th><th>Sisa</th><th>Status</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(format_period($inv->billing_period)); ?></td>
                <td><?php echo e(format_rupiah($inv->amount)); ?></td>
                <td><?php echo e(format_rupiah($inv->paid_amount)); ?></td>
                <td class="text-danger fw-semibold"><?php echo e(format_rupiah($inv->balance())); ?></td>
                <td><span class="badge <?php echo e($inv->status->badgeClass()); ?>"><?php echo e($inv->status->label()); ?></span></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php endif; ?>

<h6 class="mt-3 mb-2"><i class="bi bi-clock-history"></i> Riwayat Pembayaran</h6>
<?php if($history->isEmpty()): ?>
    <div class="card"><div class="card-body text-center text-muted small py-3">Belum ada pembayaran.</div></div>
<?php else: ?>
    <div class="d-md-none">
    <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('payments.show', $p)); ?>" class="nb-list-card">
            <div class="nb-avatar" style="background: var(--nb-primary);"><i class="bi bi-receipt"></i></div>
            <div class="nb-body">
                <p class="nb-title"><?php echo e($p->transaction_number); ?></p>
                <p class="nb-sub"><?php echo e(format_date($p->paid_at)); ?></p>
            </div>
            <div class="nb-end">
                <span class="badge <?php echo e($p->status->badgeClass()); ?>"><?php echo e(format_rupiah($p->amount_received)); ?></span>
            </div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="card d-none d-md-block">
        <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
            <thead class="table-light"><tr><th>Transaksi</th><th>Tanggal</th><th>Nominal</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('payments.show', $p)); ?>"><?php echo e($p->transaction_number); ?></a></td>
                <td class="small"><?php echo e(format_date($p->paid_at)); ?></td>
                <td><?php echo e(format_rupiah($p->amount_received)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/scan/show.blade.php ENDPATH**/ ?>