<?php $__env->startSection('title', $customer->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h4 class="mb-0"><?php echo e($customer->name); ?></h4>
        <p class="text-muted small mb-0"><?php echo e($customer->customer_code); ?> &middot; <span class="badge <?php echo e($customer->status->value === 'active' ? 'bg-success-subtle text-success-emphasis' : 'bg-warning-subtle text-warning-emphasis'); ?>"><?php echo e($customer->status->label()); ?></span></p>
    </div>
    <div class="btn-group">
        <a href="<?php echo e(route('scan.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-qr-code-scan"></i> Scan Ulang</a>
        <?php if($arrears->isNotEmpty()): ?>
        <a href="<?php echo e(route('scan.pay.form', $customer)); ?>" class="btn btn-success btn-lg"><i class="bi bi-cash"></i> Terima Pembayaran</a>
        <?php else: ?>
        <span class="btn btn-success disabled">Tidak ada tunggakan</span>
        <?php endif; ?>
    </div>
</div>

<?php if(session('warning')): ?>
<div class="alert alert-warning"><i class="bi bi-exclamation-triangle"></i> <?php echo e(session('warning')); ?></div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-md-5">
        <div class="card mb-3"><div class="card-body">
            <dl class="row mb-0 small">
                <dt class="col-5">Alamat</dt><dd class="col-7"><?php echo e($customer->address ?: '-'); ?></dd>
                <dt class="col-5">WhatsApp</dt><dd class="col-7"><?php echo e($customer->phone ?: '-'); ?></dd>
                <dt class="col-5">Paket</dt><dd class="col-7"><?php echo e($customer->package?->name ?? '-'); ?></dd>
                <dt class="col-5">Tarif</dt><dd class="col-7"><?php echo e(format_rupiah($customer->monthly_fee)); ?></dd>
            </dl>
        </div></div>
        <div class="card bg-danger text-white"><div class="card-body text-center">
            <div class="small">Total Tunggakan</div>
            <div class="fs-4 fw-bold"><?php echo e(format_rupiah($totalArrears)); ?></div>
        </div></div>
    </div>
    <div class="col-md-7">
        <div class="card mb-3"><div class="card-header bg-white"><strong>Tagihan Belum Lunas</strong></div>
        <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
            <thead class="table-light"><tr><th>Periode</th><th>Nominal</th><th>Dibayar</th><th>Sisa</th><th>Status</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e(format_period($inv->billing_period)); ?></td>
                <td><?php echo e(format_rupiah($inv->amount)); ?></td>
                <td><?php echo e(format_rupiah($inv->paid_amount)); ?></td>
                <td class="text-danger fw-semibold"><?php echo e(format_rupiah($inv->balance())); ?></td>
                <td><span class="badge <?php echo e($inv->status->badgeClass()); ?>"><?php echo e($inv->status->label()); ?></span></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-center text-success py-3">Tidak ada tunggakan. Pelanggan lunas.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div></div>

        <div class="card"><div class="card-header bg-white"><strong>Riwayat Pembayaran</strong></div>
        <div class="table-responsive">
        <table class="table table-sm align-middle mb-0">
            <thead class="table-light"><tr><th>Transaksi</th><th>Tanggal</th><th>Nominal</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><a href="<?php echo e(route('payments.show', $p)); ?>"><?php echo e($p->transaction_number); ?></a></td>
                <td class="small"><?php echo e(format_date($p->paid_at)); ?></td>
                <td><?php echo e(format_rupiah($p->amount_received)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="3" class="text-center text-muted py-3">Belum ada pembayaran.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill-collector/resources/views/scan/show.blade.php ENDPATH**/ ?>