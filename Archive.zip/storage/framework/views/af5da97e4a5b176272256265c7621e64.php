<?php $__env->startSection('title', 'Riwayat Blast WhatsApp'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h5 class="mb-0"><i class="bi bi-clock-history"></i> Riwayat Blast WhatsApp</h5>
        <p class="text-muted small mb-0">Catatan pemberitahuan penagihan yang sudah dibuka/ditandai terkirim.</p>
    </div>
    <a href="<?php echo e(route('blast.index')); ?>" class="btn btn-success btn-sm"><i class="bi bi-whatsapp"></i> Blast Baru</a>
</div>

<div class="card mb-3"><div class="card-body py-3">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-8 col-md-4">
        <label class="form-label small mb-1">Dusun</label>
        <select name="dusun" class="form-select">
            <option value="">Semua</option>
            <?php $__currentLoopData = $dusunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($d); ?>" <?php if(request('dusun') === $d): echo 'selected'; endif; ?>><?php echo e($d); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-4 col-md-2 d-grid">
        <button class="btn btn-outline-primary"><i class="bi bi-funnel"></i> Filter</button>
    </div>
</form>
</div></div>

<?php if($logs->isEmpty()): ?>
    <div class="card"><div class="card-body text-center text-muted py-5">
        <i class="bi bi-whatsapp fs-1 d-block mb-2 opacity-50"></i>
        Belum ada blast tercatat.
    </div></div>
<?php else: ?>
    <div class="d-md-none">
        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="nb-list-card">
            <div class="nb-avatar" style="background:#25D366"><i class="bi bi-whatsapp"></i></div>
            <div class="nb-body">
                <p class="nb-title"><?php echo e($log->customer?->name ?? 'Pelanggan dihapus'); ?></p>
                <p class="nb-sub"><?php echo e($log->phone ?? '-'); ?> · <?php echo e(format_datetime($log->sent_at)); ?></p>
                <p class="nb-sub">oleh <?php echo e($log->user?->name ?? '-'); ?></p>
            </div>
            <div class="nb-end">
                <div class="fw-bold text-danger"><?php echo e(format_rupiah($log->total_arrears)); ?></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card d-none d-md-block">
        <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Waktu</th><th>Pelanggan</th><th>Nomor</th><th>Tunggakan</th><th>Oleh</th><th>Pesan</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="small"><?php echo e(format_datetime($log->sent_at)); ?></td>
                <td>
                    <?php echo e($log->customer?->name ?? '—'); ?>

                    <div class="small text-muted"><?php echo e($log->customer?->customer_code); ?></div>
                </td>
                <td class="small"><?php echo e($log->phone ?? '-'); ?></td>
                <td><?php echo e(format_rupiah($log->total_arrears)); ?></td>
                <td class="small"><?php echo e($log->user?->name ?? '-'); ?></td>
                <td>
                    <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#logModal<?php echo e($log->id); ?>"><i class="bi bi-eye"></i></button>
                    <div class="modal fade" id="logModal<?php echo e($log->id); ?>" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content">
                        <div class="modal-header"><h5 class="modal-title">Pesan ke <?php echo e($log->customer?->name); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                        <div class="modal-body"><pre class="bg-light border rounded p-3 small mb-0" style="white-space:pre-wrap"><?php echo e($log->message); ?></pre></div>
                    </div></div></div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>

    <?php if($logs->hasPages()): ?>
    <div class="d-flex justify-content-center mt-3"><?php echo e($logs->links()); ?></div>
    <?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/blast/history.blade.php ENDPATH**/ ?>