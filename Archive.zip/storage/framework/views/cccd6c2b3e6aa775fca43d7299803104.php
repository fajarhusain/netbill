<?php $__env->startSection('title', 'Kartu Pelanggan'); ?>

<?php $__env->startSection('content'); ?>
<div class="no-print mb-3 d-flex gap-2">
    <a href="<?php echo e(route('customers.show', $customer)); ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left"></i> Kembali</a>
    <button onclick="window.print()" class="btn btn-primary btn-sm"><i class="bi bi-printer"></i> Cetak</button>
</div>

<div class="d-flex justify-content-center">
    <div class="card border border-dark" style="width:340px;">
        <div class="card-header text-center bg-primary text-white py-2">
            <div class="fw-bold">RT/RW NET ANDA</div>
            <div class="small">Kartu Pelanggan</div>
        </div>
        <div class="card-body text-center">
            <img src="<?php echo e(route('customers.qrcode', $customer)); ?>" alt="QR" style="width:200px;">
            <div class="mt-2"><strong><?php echo e($customer->customer_code); ?></strong></div>
            <div><?php echo e($customer->name); ?></div>
            <div class="small text-muted">Paket: <?php echo e($customer->package?->name ?? '-'); ?> &middot; <?php echo e(format_rupiah($customer->monthly_fee)); ?>/bln</div>
        </div>
        <div class="card-footer text-center small text-muted py-1">
            Pindai QR untuk penagihan
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/customers/card.blade.php ENDPATH**/ ?>