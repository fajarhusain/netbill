<?php $__env->startSection('title', 'Detail Kunjungan'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Detail Kunjungan</h4>
    <div class="btn-group">
        <a href="<?php echo e(route('visits.edit', $visit)); ?>" class="btn btn-outline-warning btn-sm"><i class="bi bi-pencil"></i> Edit</a>
        <a href="<?php echo e(route('scan.customer', $visit->customer)); ?>" class="btn btn-outline-primary btn-sm">Lihat Pelanggan</a>
    </div>
</div>
<div class="card"><div class="card-body">
<dl class="row mb-0">
    <dt class="col-sm-3">Pelanggan</dt><dd class="col-sm-9"><?php echo e($visit->customer->name); ?> (<?php echo e($visit->customer->customer_code); ?>)</dd>
    <dt class="col-sm-3">Petugas</dt><dd class="col-sm-9"><?php echo e($visit->collector->name); ?></dd>
    <dt class="col-sm-3">Waktu</dt><dd class="col-sm-9"><?php echo e(format_datetime($visit->visited_at)); ?></dd>
    <dt class="col-sm-3">Hasil</dt><dd class="col-sm-9"><?php echo e($visit->result->label()); ?></dd>
    <?php if($visit->notes): ?><dt class="col-sm-3">Catatan</dt><dd class="col-sm-9"><?php echo e($visit->notes); ?></dd><?php endif; ?>
</dl>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/visits/show.blade.php ENDPATH**/ ?>