<?php $__env->startSection('title', 'Kunjungan Penagihan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-geo-alt"></i> Kunjungan Penagihan</h4>
    <a href="<?php echo e(route('visits.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Catat Kunjungan</a>
</div>

<div class="card mb-3"><div class="card-body">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-md-4"><label class="form-label small">Cari Pelanggan</label><input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"></div>
    <div class="col-md-3"><label class="form-label small">Hasil</label><select name="result" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($r->value); ?>" <?php if(request('result')===$r->value): echo 'selected'; endif; ?>><?php echo e($r->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <?php if(auth()->user()->isAdmin() && $collectors->isNotEmpty()): ?><div class="col-md-3"><label class="form-label small">Petugas</label><select name="collector_id" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $collectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(request('collector_id')==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div><?php endif; ?>
    <div class="col-md-2 d-grid"><button class="btn btn-outline-primary"><i class="bi bi-search"></i></button></div>
</form>
</div></div>

<div class="card"><div class="table-responsive">
<table class="table table-hover align-middle mb-0">
<thead class="table-light"><tr><th>Waktu</th><th>Pelanggan</th><th>Petugas</th><th>Hasil</th><th>Catatan</th><th class="text-end">Aksi</th></tr></thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td class="small"><?php echo e(format_datetime($v->visited_at)); ?></td>
    <td><?php echo e($v->customer->name); ?><div class="small text-muted"><?php echo e($v->customer->customer_code); ?></div></td>
    <td><?php echo e($v->collector->name); ?></td>
    <td><?php echo e($v->result->label()); ?></td>
    <td class="small"><?php echo e(Illuminate\Support\Str::limit($v->notes, 40)); ?></td>
    <td class="text-end"><a href="<?php echo e(route('visits.show', $v)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="6" class="text-center text-muted py-4">Belum ada kunjungan.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<?php if($visits->hasPages()): ?><div class="card-footer bg-white"><?php echo e($visits->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill-collector/resources/views/visits/index.blade.php ENDPATH**/ ?>