<form method="POST" action="<?php echo e(isset($settlement) ? route('settlements.update', $settlement) : route('settlements.store')); ?>"><?php echo csrf_field(); ?> <?php if(isset($settlement)): ?><?php echo method_field('PUT'); ?><?php endif; ?>
<div class="row g-3">
    <?php if(auth()->user()->isAdmin()): ?>
    <div class="col-md-6">
        <label class="form-label">Petugas <span class="text-danger">*</span></label>
        <select name="collector_id" class="form-select" required <?php echo e(isset($settlement) ? 'disabled' : ''); ?>>
            <?php $__currentLoopData = $collectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(old('collector_id', isset($settlement) ? $settlement->collector_id : null)==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if(isset($settlement)): ?><input type="hidden" name="collector_id" value="<?php echo e($settlement->collector_id); ?>"><?php endif; ?>
    </div>
    <?php else: ?>
    <input type="hidden" name="collector_id" value="<?php echo e(auth()->id()); ?>">
    <?php endif; ?>
    <div class="col-md-3">
        <label class="form-label">Tanggal <span class="text-danger">*</span></label>
        <input type="date" name="settlement_date" class="form-control" value="<?php echo e(old('settlement_date', isset($settlement) ? $settlement->settlement_date->format('Y-m-d') : now()->format('Y-m-d'))); ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Uang Diserahkan (Rp) <span class="text-danger">*</span></label>
        <input type="number" name="received_amount" class="form-control" value="<?php echo e(old('received_amount', isset($settlement) ? $settlement->received_amount : '')); ?>" min="0" required>
    </div>
    <div class="col-12">
        <label class="form-label">Catatan</label>
        <textarea name="notes" class="form-control" rows="2"><?php echo e(old('notes', $settlement->notes ?? '')); ?></textarea>
    </div>
    <div class="col-12"><button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button> <a href="<?php echo e(route('settlements.index')); ?>" class="btn btn-outline-secondary">Batal</a></div>
</div>
</form>
<?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/settlements/_form.blade.php ENDPATH**/ ?>