<form method="POST" action="<?php echo e(isset($visit) ? route('visits.update', $visit) : route('visits.store')); ?>"><?php echo csrf_field(); ?> <?php if(isset($visit)): ?><?php echo method_field('PUT'); ?><?php endif; ?>
<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Pelanggan <span class="text-danger">*</span></label>
        <select name="customer_id" class="form-select" required>
            <option value="">— Pilih —</option>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(old('customer_id', isset($visit) ? $visit->customer_id : null)==$c->id): echo 'selected'; endif; ?>><?php echo e($c->customer_code); ?> — <?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-3">
        <label class="form-label">Waktu <span class="text-danger">*</span></label>
        <input type="datetime-local" name="visited_at" class="form-control" value="<?php echo e(old('visited_at', isset($visit) ? $visit->visited_at->format('Y-m-d\TH:i') : now()->format('Y-m-d\TH:i'))); ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Hasil <span class="text-danger">*</span></label>
        <select name="result" class="form-select" required><?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($r->value); ?>" <?php if(old('result', isset($visit) ? $visit->result->value : null)===$r->value): echo 'selected'; endif; ?>><?php echo e($r->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <div class="col-12">
        <label class="form-label">Catatan</label>
        <textarea name="notes" class="form-control" rows="2"><?php echo e(old('notes', $visit->notes ?? '')); ?></textarea>
    </div>
    <div class="col-12"><button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button> <a href="<?php echo e(route('visits.index')); ?>" class="btn btn-outline-secondary">Batal</a></div>
</div>
</form>
<?php /**PATH /Users/fajarhusainasyari/netbill-collector/resources/views/visits/_form.blade.php ENDPATH**/ ?>