<?php $__env->startSection('title', isset($user) ? 'Edit Pengguna' : 'Tambah Pengguna'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-person-plus"></i> <?php echo e(isset($user) ? 'Edit Pengguna' : 'Tambah Pengguna'); ?></h4>
    <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
</div>
<div class="card"><div class="card-body">
<form method="POST" action="<?php echo e(isset($user) ? route('users.update', $user) : route('users.store')); ?>"><?php echo csrf_field(); ?> <?php if(isset($user)): ?><?php echo method_field('PUT'); ?><?php endif; ?>
<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Nama <span class="text-danger">*</span></label>
        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $user->name ?? '')); ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Username <span class="text-danger">*</span></label>
        <input type="text" name="username" class="form-control" value="<?php echo e(old('username', $user->username ?? '')); ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Kata Sandi <?php echo e(isset($user) ? '(kosongkan jika tidak diubah)' : '*'); ?></label>
        <input type="password" name="password" class="form-control" <?php if(!isset($user)): ?>required <?php endif; ?>>
    </div>
    <div class="col-md-6">
        <label class="form-label">Ulangi Kata Sandi</label>
        <input type="password" name="password_confirmation" class="form-control">
    </div>
    <div class="col-md-6">
        <label class="form-label">Role <span class="text-danger">*</span></label>
        <select name="role" class="form-select" required><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($r->value); ?>" <?php if(old('role', $user->role->value ?? 'collector')===$r->value): echo 'selected'; endif; ?>><?php echo e($r->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <div class="col-md-6 d-flex align-items-end">
        <div class="form-check"><input type="checkbox" name="is_active" value="1" class="form-check-input" id="ua" <?php echo e(old('is_active', isset($user) ? $user->is_active : true) ? 'checked' : ''); ?>><label class="form-check-label" for="ua">Aktif</label></div>
    </div>
    <div class="col-12"><button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button></div>
</div>
</form>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/users/_form.blade.php ENDPATH**/ ?>