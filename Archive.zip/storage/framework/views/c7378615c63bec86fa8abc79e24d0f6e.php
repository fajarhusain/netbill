<?php $__env->startSection('title', 'Dusun ' . $dusun->name); ?>

<?php
    $avatarColors = ['#0d6efd','#6610f2','#0dcaf0','#198754','#fd7e14','#dc3545','#d63384','#6f42c1'];
?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center mb-3 gap-2">
    <a href="<?php echo e(route('collections.index')); ?>" class="btn btn-outline-secondary btn-touch"><i class="bi bi-arrow-left"></i></a>
    <div class="flex-grow-1 min-w-0">
        <h5 class="mb-0"><i class="bi bi-geo-alt"></i> <?php echo e($dusun->name); ?></h5>
        <p class="text-muted small mb-0"><?php echo e($customers->count()); ?> pelanggan · <?php echo e($withArrears); ?> menunggak</p>
    </div>
    <a href="<?php echo e(route('blast.index', ['dusun' => $dusun->name])); ?>" class="btn btn-success btn-touch"><i class="bi bi-whatsapp"></i></a>
</div>

<?php if($totalArrears > 0): ?>
<div class="card bg-danger text-white mb-3"><div class="card-body py-2">
    <div class="d-flex justify-content-between align-items-center">
        <div class="small">Total Tunggakan</div>
        <div class="fw-bold fs-5"><?php echo e(format_rupiah($totalArrears)); ?></div>
    </div>
</div></div>
<?php else: ?>
<div class="card bg-success text-white mb-3"><div class="card-body py-2">
    <div class="small"><i class="bi bi-check-circle"></i> Semua pelanggan lunas.</div>
</div></div>
<?php endif; ?>

<div class="mb-3">
    <div class="btn-group w-100">
        <a href="<?php echo e(route('collections.show', $dusun->id)); ?>" class="btn btn-outline-secondary btn-touch <?php echo e(!request('filter') ? 'active' : ''); ?>">Semua</a>
        <a href="<?php echo e(route('collections.show', [$dusun->id, 'filter' => 'arrears'])); ?>" class="btn btn-outline-danger btn-touch <?php echo e(request('filter') === 'arrears' ? 'active' : ''); ?>">Menunggak (<?php echo e($withArrears); ?>)</a>
    </div>
</div>

<?php if($customers->isEmpty()): ?>
    <div class="card"><div class="card-body text-center text-muted py-5">
        <i class="bi bi-people fs-1 d-block mb-2 opacity-50"></i>
        Tidak ada pelanggan yang sesuai.
    </div></div>
<?php else: ?>
    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $initial = mb_strtoupper(mb_substr($c->name, 0, 1));
        $colorIdx = ord($initial) % count($avatarColors);
        $arrears = (int) $c->invoices->sum(fn ($i) => $i->balance());
    ?>
    <a href="<?php echo e(route('scan.customer', $c)); ?>" class="nb-list-card">
        <div class="nb-avatar" style="background:<?php echo e($avatarColors[$colorIdx]); ?>"><?php echo e($initial); ?></div>
        <div class="nb-body">
            <p class="nb-title"><?php echo e($c->name); ?></p>
            <p class="nb-sub"><?php echo e($c->customer_code); ?> · <?php echo e($c->package?->name ?? '-'); ?></p>
        </div>
        <div class="nb-end">
            <?php if($arrears > 0): ?>
            <div class="fw-bold text-danger"><?php echo e(format_rupiah($arrears)); ?></div>
            <?php else: ?>
            <div class="text-success small"><i class="bi bi-check-circle"></i> Lunas</div>
            <?php endif; ?>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/collections/show.blade.php ENDPATH**/ ?>