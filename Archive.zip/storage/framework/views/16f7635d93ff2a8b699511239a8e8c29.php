<?php $__env->startSection('title', 'Dashboard'); ?>

<?php
    $isCollector = ! auth()->user()->isAdmin();
    $initials = collect(mb_str_split(auth()->user()->name))->take(2)->join('');
?>

<?php $__env->startSection('content'); ?>
<?php if($isCollector): ?>
    <div class="nb-hero mb-3">
        <div class="d-flex align-items-center mb-2">
            <div class="nb-avatar" style="width:44px;height:44px;background:rgba(255,255,255,.25);margin-right:.6rem;"><?php echo e($initials); ?></div>
            <div>
                <div class="small opacity-75">Halo,</div>
                <div class="fw-bold"><?php echo e(auth()->user()->name); ?></div>
            </div>
        </div>
        <div class="small opacity-75 mb-3"><?php echo e(format_datetime($now)); ?></div>

        <div class="row g-2 mb-3">
            <div class="col-6">
                <div class="small opacity-75"><i class="bi bi-cash-coin"></i> Penerimaan Hari Ini</div>
                <div class="fs-5 fw-bold"><?php echo e(format_rupiah($paidToday)); ?></div>
            </div>
            <div class="col-6">
                <div class="small opacity-75"><i class="bi bi-wallet2"></i> Belum Disetor</div>
                <div class="fs-5 fw-bold"><?php echo e(format_rupiah($pendingSettlement)); ?></div>
            </div>
        </div>

        <a href="<?php echo e(route('scan.index')); ?>" class="btn btn-light btn-lg btn-touch w-100 fw-bold">
            <i class="bi bi-qr-code-scan"></i> Mulai Scan & Tagih
        </a>
    </div>

    <div class="row g-2 mb-3">
        <div class="col-6">
            <div class="card stat-card h-100"><div class="card-body py-2">
                <div class="text-muted small"><i class="bi bi-graph-up"></i> Bulan Ini</div>
                <div class="stat-value"><?php echo e(format_rupiah($paidThisMonth)); ?></div>
            </div></div>
        </div>
        <div class="col-6">
            <div class="card stat-card h-100"><div class="card-body py-2">
                <div class="text-muted small"><i class="bi bi-geo-alt"></i> Kunjungan Hari Ini</div>
                <div class="stat-value"><?php echo e($visitsToday); ?></div>
            </div></div>
        </div>
    </div>
<?php else: ?>
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
        <div>
            <h4 class="mb-0">Dashboard</h4>
            <p class="text-muted small mb-0"><?php echo e(format_datetime($now)); ?></p>
        </div>
        <div class="btn-group">
            <a href="<?php echo e(route('scan.index')); ?>" class="btn btn-primary btn-touch"><i class="bi bi-qr-code-scan"></i> Scan</a>
            <a href="<?php echo e(route('invoices.create')); ?>" class="btn btn-outline-primary btn-touch"><i class="bi bi-file-text"></i> Buat Tagihan</a>
        </div>
    </div>

    <div class="row g-2 mb-3">
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="text-muted small"><i class="bi bi-people"></i> Total Pelanggan</div>
                <div class="stat-value"><?php echo e(number_format($totalCustomers)); ?></div>
                <div class="small text-success"><?php echo e($activeCustomers); ?> aktif</div>
            </div></div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="text-muted small"><i class="bi bi-file-text"></i> Tagihan <?php echo e(format_period($currentPeriod)); ?></div>
                <div class="stat-value"><?php echo e(format_rupiah($totalInvoicedCurrentPeriod)); ?></div>
            </div></div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="text-muted small"><i class="bi bi-cash-coin"></i> Penerimaan Hari Ini</div>
                <div class="stat-value text-success"><?php echo e(format_rupiah($paidToday)); ?></div>
            </div></div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="text-muted small"><i class="bi bi-graph-up"></i> Penerimaan Bulan Ini</div>
                <div class="stat-value"><?php echo e(format_rupiah($paidThisMonth)); ?></div>
            </div></div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="text-muted small"><i class="bi bi-exclamation-triangle"></i> Total Tunggakan</div>
                <div class="stat-value text-danger"><?php echo e(format_rupiah($arrearsTotal)); ?></div>
            </div></div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="text-muted small"><i class="bi bi-person-x"></i> Belum Bayar</div>
                <div class="stat-value"><?php echo e(number_format($unpaidCustomerCount)); ?></div>
            </div></div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="text-muted small"><i class="bi bi-geo-alt"></i> Kunjungan Hari Ini</div>
                <div class="stat-value"><?php echo e($visitsToday); ?></div>
            </div></div>
        </div>
        <div class="col-6 col-md-4 col-lg-3">
            <div class="card stat-card h-100"><div class="card-body">
                <div class="text-muted small"><i class="bi bi-bank"></i> Kas Belum Disetor</div>
                <div class="stat-value text-warning"><?php echo e(format_rupiah($pendingSettlement)); ?></div>
            </div></div>
        </div>
    </div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-2">
    <h6 class="mb-0"><i class="bi bi-clock-history"></i> Transaksi Terbaru</h6>
    <a href="<?php echo e(route('payments.index')); ?>" class="small text-decoration-none">Lihat semua</a>
</div>

<?php if($recentPayments->isEmpty()): ?>
    <div class="card mb-3"><div class="card-body text-center text-muted small py-4">Belum ada transaksi.</div></div>
<?php else: ?>
    <div class="d-md-none">
        <?php $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('payments.show', $p)); ?>" class="nb-list-card">
            <div class="nb-avatar" style="background: var(--nb-primary);"><?php echo e(mb_strtoupper(mb_substr($p->customer->name, 0, 1))); ?></div>
            <div class="nb-body">
                <p class="nb-title"><?php echo e($p->customer->name); ?></p>
                <p class="nb-sub"><?php echo e($p->transaction_number); ?> · <?php echo e(format_datetime($p->paid_at)); ?></p>
            </div>
            <div class="nb-end">
                <div class="fw-bold text-success"><?php echo e(format_rupiah($p->amount_received)); ?></div>
                <span class="badge <?php echo e($p->status->badgeClass()); ?>"><?php echo e($p->status->label()); ?></span>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="card d-none d-md-block">
        <div class="table-responsive">
            <table class="table table-sm table-hover align-middle mb-0">
                <thead class="table-light"><tr><th>No. Transaksi</th><th>Pelanggan</th><th>Nominal</th><th>Waktu</th></tr></thead>
                <tbody>
                <?php $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><a href="<?php echo e(route('payments.show', $p)); ?>" class="text-decoration-none"><?php echo e($p->transaction_number); ?></a></td>
                        <td><?php echo e($p->customer->name); ?><div class="small text-muted"><?php echo e($p->customer->customer_code); ?></div></td>
                        <td class="fw-semibold"><?php echo e(format_rupiah($p->amount_received)); ?></td>
                        <td class="small"><?php echo e(format_datetime($p->paid_at)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/dashboard.blade.php ENDPATH**/ ?>