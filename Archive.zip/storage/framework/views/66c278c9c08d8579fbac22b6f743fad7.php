<?php $__env->startSection('title', 'Setoran Petugas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-wallet2"></i> <?php echo e(auth()->user()->isAdmin() ? 'Setoran Petugas' : 'Setoran Saya'); ?></h5>
    <a href="<?php echo e(route('settlements.create')); ?>" class="btn btn-primary btn-touch"><i class="bi bi-plus-lg"></i> Catat</a>
</div>

<div class="card <?php if($pendingCash > 0): ?> bg-warning-subtle border-warning <?php else: ?> bg-success-subtle border-success <?php endif; ?> mb-3">
    <div class="card-body d-flex align-items-center">
        <i class="bi <?php if($pendingCash > 0): ?> bi-exclamation-triangle <?php else: ?> bi-check-circle <?php endif; ?> fs-3 me-3"></i>
        <div class="flex-grow-1">
            <div class="small text-muted">Kas tunai belum disetor</div>
            <div class="fw-bold fs-5"><?php echo e(format_rupiah($pendingCash)); ?></div>
        </div>
    </div>
</div>

<?php if($settlements->isEmpty()): ?>
    <div class="card"><div class="card-body text-center text-muted py-5">
        <i class="bi bi-bank fs-1 d-block mb-2 opacity-50"></i>
        Belum ada setoran.
    </div></div>
<?php else: ?>
    <div class="d-md-none">
        <?php $__currentLoopData = $settlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('settlements.show', $s)); ?>" class="nb-list-card">
            <div class="nb-avatar" style="background:#198754;"><i class="bi bi-bank"></i></div>
            <div class="nb-body">
                <p class="nb-title"><?php echo e(format_date($s->settlement_date)); ?></p>
                <p class="nb-sub">Diterima: <?php echo e(format_rupiah($s->received_amount)); ?> <?php if($s->difference_amount != 0): ?> · <span class="<?php echo e($s->difference_amount < 0 ? 'text-danger' : 'text-success'); ?>"><?php echo e(format_rupiah($s->difference_amount)); ?></span><?php endif; ?></p>
            </div>
            <div class="nb-end">
                <?php if($s->isConfirmed()): ?><span class="badge bg-success-subtle text-success-emphasis">Dikonfirmasi</span><?php else: ?><span class="badge bg-warning-subtle text-warning-emphasis">Menunggu</span><?php endif; ?>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card d-none d-md-block">
        <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Tanggal</th><?php if(auth()->user()->isAdmin()): ?><th>Petugas</th><?php endif; ?><th>Diharapkan</th><th>Diterima</th><th>Selisih</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $settlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(format_date($s->settlement_date)); ?></td>
                <?php if(auth()->user()->isAdmin()): ?><td><?php echo e($s->collector->name); ?></td><?php endif; ?>
                <td><?php echo e(format_rupiah($s->expected_amount)); ?></td>
                <td><?php echo e(format_rupiah($s->received_amount)); ?></td>
                <td class="<?php echo e($s->difference_amount < 0 ? 'text-danger' : ($s->difference_amount > 0 ? 'text-success' : '')); ?>"><?php echo e(format_rupiah($s->difference_amount)); ?></td>
                <td><?php if($s->isConfirmed()): ?><span class="badge bg-success-subtle text-success-emphasis">Dikonfirmasi</span><?php else: ?><span class="badge bg-warning-subtle text-warning-emphasis">Menunggu</span><?php endif; ?></td>
                <td class="text-end"><a href="<?php echo e(route('settlements.show', $s)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        </div>
    </div>
<?php endif; ?>

<?php if($settlements->hasPages()): ?>
<div class="d-flex justify-content-center mt-3"><?php echo e($settlements->links()); ?></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/settlements/index.blade.php ENDPATH**/ ?>