<?php $__env->startSection('title', $invoice->invoice_number); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h4 class="mb-0"><?php echo e($invoice->invoice_number); ?></h4>
        <p class="text-muted small mb-0">Periode <?php echo e(format_period($invoice->billing_period)); ?></p>
    </div>
    <div class="btn-group">
        <a href="<?php echo e(route('customers.show', $invoice->customer)); ?>" class="btn btn-outline-secondary btn-sm">Lihat Pelanggan</a>
        <?php if(in_array($invoice->status->value, ['unpaid','partial'])): ?>
        <button class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#cancelModal"><i class="bi bi-x-circle"></i> Batalkan</button>
        <?php endif; ?>
        <?php if($invoice->allocations->isEmpty()): ?>
        <form action="<?php echo e(route('invoices.destroy', $invoice)); ?>" method="POST" id="deleteForm" class="d-inline"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?></form>
        <button type="button" class="btn btn-outline-danger btn-sm" onclick="confirmDeleteInvoice()"><i class="bi bi-trash"></i> Hapus</button>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3">
<div class="col-md-6">
    <div class="card"><div class="card-header bg-white"><strong>Detail Tagihan</strong></div><div class="card-body">
        <dl class="row mb-0">
            <dt class="col-5">Pelanggan</dt><dd class="col-7"><?php echo e($invoice->customer->name); ?> (<?php echo e($invoice->customer->customer_code); ?>)</dd>
            <dt class="col-5">Paket</dt><dd class="col-7"><?php echo e($invoice->customer->package?->name ?? '-'); ?></dd>
            <dt class="col-5">Diterbitkan</dt><dd class="col-7"><?php echo e(format_date($invoice->issued_at)); ?></dd>
            <dt class="col-5">Jatuh Tempo</dt><dd class="col-7"><?php echo e(format_date($invoice->due_date)); ?></dd>
            <dt class="col-5">Nominal</dt><dd class="col-7"><?php echo e(format_rupiah($invoice->amount)); ?></dd>
            <dt class="col-5">Dibayar</dt><dd class="col-7"><?php echo e(format_rupiah($invoice->paid_amount)); ?></dd>
            <dt class="col-5">Sisa</dt><dd class="col-7 fw-semibold text-danger"><?php echo e(format_rupiah($invoice->balance())); ?></dd>
            <dt class="col-5">Status</dt><dd class="col-7"><span class="badge <?php echo e($invoice->status->badgeClass()); ?>"><?php echo e($invoice->status->label()); ?></span></dd>
        </dl>
    </div></div>
</div>
<div class="col-md-6">
    <div class="card"><div class="card-header bg-white"><strong>Alokasi Pembayaran</strong></div><div class="card-body p-0">
    <?php if($invoice->allocations->isEmpty()): ?>
        <div class="p-4 text-center text-muted small">Belum ada pembayaran.</div>
    <?php else: ?>
        <div class="table-responsive"><table class="table table-sm mb-0">
            <thead class="table-light"><tr><th>No. Transaksi</th><th>Petugas</th><th>Nominal</th><th>Tanggal</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $invoice->allocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="<?php echo e(route('payments.show', $a->payment)); ?>"><?php echo e($a->payment->transaction_number); ?></a></td>
                    <td><?php echo e($a->payment->collector->name); ?></td>
                    <td><?php echo e(format_rupiah($a->amount_allocated)); ?></td>
                    <td class="small"><?php echo e(format_date($a->payment->paid_at)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table></div>
    <?php endif; ?>
    </div></div>
</div>
</div>

<div class="modal fade" id="cancelModal" tabindex="-1">
<div class="modal-dialog"><div class="modal-content"><form method="POST" action="<?php echo e(route('invoices.cancel', $invoice)); ?>"><?php echo csrf_field(); ?>
    <div class="modal-header"><h5 class="modal-title">Batalkan Tagihan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
        <div class="alert alert-warning small">Tagihan dengan pembayaran tidak dapat dibatalkan. Batalkan transaksi pembayaran terlebih dahulu.</div>
        <label class="form-label">Alasan Pembatalan <span class="text-danger">*</span></label>
        <textarea name="reason" class="form-control" rows="3" required minlength="5"></textarea>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button class="btn btn-danger">Batalkan Tagihan</button></div>
</form></div></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDeleteInvoice() {
    Swal.fire({
        icon: 'warning',
        title: 'Hapus Tagihan?',
        html: 'Tagihan <strong><?php echo e($invoice->invoice_number); ?></strong> akan dihapus permanen.<br>Tindakan ini tidak dapat dibatalkan.',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#64748b',
    }).then(function (result) {
        if (result.isConfirmed) {
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/invoices/show.blade.php ENDPATH**/ ?>