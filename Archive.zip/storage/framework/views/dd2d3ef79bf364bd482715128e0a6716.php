<?php $__env->startSection('title', 'Tambah Dusun'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-plus-lg"></i> Tambah Dusun</h4>
    <a href="<?php echo e(route('dusun.index')); ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
</div>
<div class="card"><div class="card-body">
<form method="POST" action="<?php echo e(route('dusun.store')); ?>"><?php echo csrf_field(); ?> <?php echo $__env->make('dusun._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></form>
</div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/dusun/create.blade.php ENDPATH**/ ?>