<?php $__env->startSection('title', 'Detail Setoran'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <h4 class="mb-0">Detail Setoran</h4>
    <div class="btn-group">
        <?php if(!$settlement->isConfirmed()): ?><a href="<?php echo e(route('settlements.edit', $settlement)); ?>" class="btn btn-outline-warning btn-sm"><i class="bi bi-pencil"></i> Edit</a><?php endif; ?>
        <?php if(auth()->user()->isAdmin() && !$settlement->isConfirmed()): ?>
        <form method="POST" action="<?php echo e(route('settlements.confirm', $settlement)); ?>"><?php echo csrf_field(); ?><button class="btn btn-success btn-sm"><i class="bi bi-check-lg"></i> Konfirmasi</button></form>
        <?php endif; ?>
    </div>
</div>
<?php if($settlement->difference_amount != 0): ?>
<div class="alert <?php echo e($settlement->difference_amount < 0 ? 'alert-danger' : 'alert-success'); ?>"><i class="bi bi-info-circle"></i> Selisih kas: <strong><?php echo e(format_rupiah($settlement->difference_amount)); ?></strong> <?php if($settlement->difference_amount < 0): ?>(kurang)<?php else: ?><?php endif; ?></div>
<?php endif; ?>
<div class="card"><div class="card-body">
<dl class="row mb-0">
    <dt class="col-sm-3">Petugas</dt><dd class="col-sm-9"><?php echo e($settlement->collector->name); ?></dd>
    <dt class="col-sm-3">Tanggal</dt><dd class="col-sm-9"><?php echo e(format_date($settlement->settlement_date)); ?></dd>
    <dt class="col-sm-3">Diharapkan</dt><dd class="col-sm-9"><?php echo e(format_rupiah($settlement->expected_amount)); ?></dd>
    <dt class="col-sm-3">Diterima</dt><dd class="col-sm-9"><?php echo e(format_rupiah($settlement->received_amount)); ?></dd>
    <dt class="col-sm-3">Selisih</dt><dd class="col-sm-9 fw-bold"><?php echo e(format_rupiah($settlement->difference_amount)); ?></dd>
    <dt class="col-sm-3">Status</dt><dd class="col-sm-9"><?php if($settlement->isConfirmed()): ?><span class="badge bg-success-subtle text-success-emphasis">Dikonfirmasi <?php echo e(format_datetime($settlement->confirmed_at)); ?></span><?php else: ?><span class="badge bg-warning-subtle text-warning-emphasis">Menunggu</span><?php endif; ?></dd>
    <?php if($settlement->notes): ?><dt class="col-sm-3">Catatan</dt><dd class="col-sm-9"><?php echo e($settlement->notes); ?></dd><?php endif; ?>
</dl>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/settlements/show.blade.php ENDPATH**/ ?>