<?php $__env->startSection('title', 'Laporan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-bar-chart"></i> Laporan Keuangan</h4>
</div>

<div class="card mb-3"><div class="card-body">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-md-4"><label class="form-label small">Dari</label><input type="date" name="date_from" value="<?php echo e($dateFrom); ?>" class="form-control"></div>
    <div class="col-md-4"><label class="form-label small">Sampai</label><input type="date" name="date_to" value="<?php echo e($dateTo); ?>" class="form-control"></div>
    <div class="col-md-2 d-grid"><button class="btn btn-outline-primary"><i class="bi bi-funnel"></i> Filter</button></div>
    <div class="col-md-2 d-grid"><a href="<?php echo e(route('reports.export', ['date_from' => $dateFrom, 'date_to' => $dateTo])); ?>" class="btn btn-success"><i class="bi bi-file-earmark-spreadsheet"></i> CSV</a></div>
</form>
</div></div>

<div class="row g-3 mb-3">
    <div class="col-6 col-md-4"><div class="card stat-card"><div class="card-body"><div class="small text-muted">Total Penerimaan</div><div class="stat-value text-success"><?php echo e(format_rupiah($totalReceived)); ?></div><div class="small"><?php echo e($totalTransactions); ?> transaksi</div></div></div></div>
    <div class="col-6 col-md-4"><div class="card stat-card"><div class="card-body"><div class="small text-muted">Total Tunggakan</div><div class="stat-value text-danger"><?php echo e(format_rupiah($totalArrears)); ?></div></div></div></div>
    <div class="col-6 col-md-4"><div class="card stat-card"><div class="card-body"><div class="small text-muted">Pelanggan Aktif</div><div class="stat-value"><?php echo e($customerStats['active']); ?>/<?php echo e($customerStats['total']); ?></div><div class="small text-muted"><?php echo e($customerStats['inactive']); ?> nonaktif, <?php echo e($customerStats['suspended']); ?> ditangguhkan</div></div></div></div>
</div>

<div class="row g-3">
<div class="col-md-6">
    <div class="card"><div class="card-header bg-white"><strong>Per Petugas</strong></div>
    <div class="table-responsive"><table class="table table-sm mb-0">
        <thead class="table-light"><tr><th>Petugas</th><th>Transaksi</th><th>Total</th></tr></thead>
        <tbody><?php $__empty_1 = true; $__currentLoopData = $byCollector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($r->collector->name); ?></td><td><?php echo e($r->tx_count); ?></td><td><?php echo e(format_rupiah($r->total)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3" class="text-center text-muted">Tidak ada data.</td></tr><?php endif; ?></tbody>
    </table></div></div>
</div>
<div class="col-md-6">
    <div class="card"><div class="card-header bg-white"><strong>Per Metode</strong></div>
    <div class="table-responsive"><table class="table table-sm mb-0">
        <thead class="table-light"><tr><th>Metode</th><th>Transaksi</th><th>Total</th></tr></thead>
        <tbody><?php $__empty_1 = true; $__currentLoopData = $byMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e(\App\Enums\PaymentMethod::from($r->payment_method)->label()); ?></td><td><?php echo e($r->tx_count); ?></td><td><?php echo e(format_rupiah($r->total)); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3" class="text-center text-muted">Tidak ada data.</td></tr><?php endif; ?></tbody>
    </table></div></div>
</div>
<div class="col-12">
    <div class="card"><div class="card-header bg-white"><strong>Setoran & Selisih Kas</strong></div>
    <div class="table-responsive"><table class="table table-sm mb-0">
        <thead class="table-light"><tr><th>Tanggal</th><th>Petugas</th><th>Diharapkan</th><th>Diterima</th><th>Selisih</th><th>Status</th></tr></thead>
        <tbody><?php $__empty_1 = true; $__currentLoopData = $cashSettlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e(format_date($s->settlement_date)); ?></td><td><?php echo e($s->collector->name); ?></td><td><?php echo e(format_rupiah($s->expected_amount)); ?></td><td><?php echo e(format_rupiah($s->received_amount)); ?></td><td class="<?php echo e($s->difference_amount<0?'text-danger':''); ?>"><?php echo e(format_rupiah($s->difference_amount)); ?></td><td><?php if($s->isConfirmed()): ?><span class="badge bg-success-subtle text-success-emphasis">Dikonfirmasi</span><?php else: ?><span class="badge bg-warning-subtle text-warning-emphasis">Menunggu</span><?php endif; ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="text-center text-muted">Tidak ada setoran.</td></tr><?php endif; ?></tbody>
    </table></div></div>
</div>
<div class="col-12">
    <div class="card"><div class="card-header bg-white"><strong>Tagihan Belum Lunas</strong></div>
    <div class="table-responsive"><table class="table table-sm mb-0">
        <thead class="table-light"><tr><th>Pelanggan</th><th>Periode</th><th>Nominal</th><th>Sisa</th></tr></thead>
        <tbody><?php $__empty_1 = true; $__currentLoopData = $arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($inv->customer->name); ?> (<?php echo e($inv->customer->customer_code); ?>)</td><td><?php echo e(format_period($inv->billing_period)); ?></td><td><?php echo e(format_rupiah($inv->amount)); ?></td><td class="text-danger"><?php echo e(format_rupiah($inv->balance())); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4" class="text-center text-muted">Tidak ada tunggakan.</td></tr><?php endif; ?></tbody>
    </table></div></div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill-collector/resources/views/reports/index.blade.php ENDPATH**/ ?>