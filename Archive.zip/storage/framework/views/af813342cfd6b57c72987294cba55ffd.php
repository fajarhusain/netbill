<?php $__env->startSection('title', 'Laporan'); ?>

<?php
    $exportParams = ['date_from' => $dateFrom, 'date_to' => $dateTo];
    if ($dusun) { $exportParams['dusun'] = $dusun; }
    if ($statusFilter) { $exportParams['status'] = $statusFilter; }
    $showArrears = in_array($statusFilter, [null, 'arrears']);
    $showPaid = in_array($statusFilter, [null, 'paid']);
?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><i class="bi bi-bar-chart"></i> Laporan Keuangan</h5>
</div>

<div class="card mb-3"><div class="card-body py-3">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-6 col-md-2"><label class="form-label small mb-1">Dari</label><input type="date" name="date_from" value="<?php echo e($dateFrom); ?>" class="form-control"></div>
    <div class="col-6 col-md-2"><label class="form-label small mb-1">Sampai</label><input type="date" name="date_to" value="<?php echo e($dateTo); ?>" class="form-control"></div>
    <div class="col-6 col-md-2">
        <label class="form-label small mb-1">Dusun</label>
        <select name="dusun" class="form-select">
            <option value="">Semua Dusun</option>
            <?php $__currentLoopData = $dusunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d); ?>" <?php if($dusun === $d): echo 'selected'; endif; ?>><?php echo e($d); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small mb-1">Status</label>
        <select name="status" class="form-select">
            <option value="">Semua</option>
            <option value="arrears" <?php if($statusFilter === 'arrears'): echo 'selected'; endif; ?>>Menunggak</option>
            <option value="paid" <?php if($statusFilter === 'paid'): echo 'selected'; endif; ?>>Lunas</option>
        </select>
    </div>
    <div class="col-6 col-md-1 d-grid"><button class="btn btn-outline-primary btn-touch"><i class="bi bi-funnel"></i></button></div>
    <div class="col-6 col-md-3">
        <div class="btn-group w-100">
            <a href="<?php echo e(route('reports.export', $exportParams)); ?>" class="btn btn-outline-secondary btn-touch"><i class="bi bi-filetype-csv"></i> CSV</a>
            <a href="<?php echo e(route('reports.export.excel', $exportParams)); ?>" class="btn btn-outline-secondary btn-touch"><i class="bi bi-file-earmark-spreadsheet"></i> Excel</a>
            <a href="<?php echo e(route('reports.export.pdf', $exportParams)); ?>" class="btn btn-outline-danger btn-touch"><i class="bi bi-file-pdf"></i> PDF</a>
        </div>
    </div>
</form>
<?php if($dusun): ?>
<div class="mt-2">
    <span class="badge text-bg-primary"><i class="bi bi-geo-alt"></i> <?php echo e($dusun); ?></span>
    <a href="<?php echo e(route('reports.index', array_merge($exportParams, ['dusun' => '']))); ?>" class="small text-decoration-none">Hapus filter dusun</a>
</div>
<?php endif; ?>
</div></div>

<div class="row g-2 mb-3">
    <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body py-2">
        <div class="small text-muted"><i class="bi bi-cash-coin"></i> Penerimaan</div>
        <div class="stat-value text-success"><?php echo e(format_rupiah($totalReceived)); ?></div>
        <div class="small"><?php echo e($totalTransactions); ?> transaksi</div>
    </div></div></div>
    <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body py-2">
        <div class="small text-muted"><i class="bi bi-exclamation-triangle"></i> Tunggakan</div>
        <div class="stat-value text-danger"><?php echo e(format_rupiah($totalArrears)); ?></div>
    </div></div></div>
    <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body py-2">
        <div class="small text-muted"><i class="bi bi-check-circle"></i> Pelanggan Lunas</div>
        <div class="stat-value text-success"><?php echo e($paidInvoices->count()); ?></div>
    </div></div></div>
    <div class="col-6 col-md-3"><div class="card stat-card"><div class="card-body py-2">
        <div class="small text-muted"><i class="bi bi-people"></i> Pelanggan Aktif</div>
        <div class="stat-value"><?php echo e($customerStats['active']); ?>/<?php echo e($customerStats['total']); ?></div>
    </div></div></div>
</div>

<div class="row g-3">
<div class="col-md-6">
    <div class="card h-100"><div class="card-header bg-white"><strong>Per Petugas</strong></div>
    <div class="card-body p-0">
        <?php $__empty_1 = true; $__currentLoopData = $byCollector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="nb-list-card mb-0 rounded-0 border-bottom">
            <div class="nb-avatar" style="background:#6610f2;"><i class="bi bi-person"></i></div>
            <div class="nb-body">
                <p class="nb-title"><?php echo e($r->collector->name); ?></p>
                <p class="nb-sub"><?php echo e($r->tx_count); ?> transaksi</p>
            </div>
            <div class="nb-end">
                <div class="fw-bold"><?php echo e(format_rupiah($r->total)); ?></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="p-4 text-center text-muted small">Tidak ada data.</div>
        <?php endif; ?>
    </div></div>
</div>
<div class="col-md-6">
    <div class="card h-100"><div class="card-header bg-white"><strong>Per Metode</strong></div>
    <div class="card-body p-0">
        <?php $__empty_1 = true; $__currentLoopData = $byMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="nb-list-card mb-0 rounded-0 border-bottom">
            <div class="nb-avatar" style="background:#0d6efd;"><i class="bi bi-credit-card"></i></div>
            <div class="nb-body">
                <p class="nb-title"><?php echo e($r->method->label()); ?></p>
                <p class="nb-sub"><?php echo e($r->tx_count); ?> transaksi</p>
            </div>
            <div class="nb-end">
                <div class="fw-bold"><?php echo e(format_rupiah($r->total)); ?></div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="p-4 text-center text-muted small">Tidak ada data.</div>
        <?php endif; ?>
    </div></div>
</div>

<div class="col-12">
    <div class="card"><div class="card-header bg-white"><strong>Setoran & Selisih Kas</strong></div>
    <div class="table-responsive">
    <table class="table table-sm mb-0">
        <thead class="table-light"><tr><th>Tanggal</th><th>Petugas</th><th class="text-end">Diharapkan</th><th class="text-end">Diterima</th><th class="text-end">Selisih</th><th>Status</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $cashSettlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e(format_date($s->settlement_date)); ?></td>
            <td><?php echo e($s->collector->name); ?></td>
            <td class="text-end"><?php echo e(format_rupiah($s->expected_amount)); ?></td>
            <td class="text-end"><?php echo e(format_rupiah($s->received_amount)); ?></td>
            <td class="text-end <?php echo e($s->difference_amount < 0 ? 'text-danger' : ''); ?>"><?php echo e(format_rupiah($s->difference_amount)); ?></td>
            <td><?php if($s->isConfirmed()): ?><span class="badge bg-success-subtle text-success-emphasis">Dikonfirmasi</span><?php else: ?><span class="badge bg-warning-subtle text-warning-emphasis">Menunggu</span><?php endif; ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6" class="text-center text-muted py-3">Tidak ada setoran.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div></div>
</div>

<?php if($showArrears): ?>
<div class="col-12">
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <strong><i class="bi bi-exclamation-triangle text-danger"></i> Pelanggan Menunggak</strong>
            <span class="badge text-bg-danger"><?php echo e($arrears->count()); ?> tagihan</span>
        </div>
        <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead class="table-light"><tr><th>Pelanggan</th><th>Dusun</th><th>Periode</th><th class="text-end">Nominal</th><th class="text-end">Sisa</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($inv->customer->name); ?> <span class="text-muted small"><?php echo e($inv->customer->customer_code); ?></span></td>
                <td><?php echo e($inv->customer->dusun ?: '-'); ?></td>
                <td><?php echo e(format_period($inv->billing_period)); ?></td>
                <td class="text-end"><?php echo e(format_rupiah($inv->amount)); ?></td>
                <td class="text-end text-danger fw-semibold"><?php echo e(format_rupiah($inv->balance())); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-center text-success py-3"><i class="bi bi-check-circle"></i> Tidak ada tunggakan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($showPaid): ?>
<div class="col-12">
    <div class="card">
        <div class="card-header bg-white d-flex justify-content-between align-items-center">
            <strong><i class="bi bi-check-circle text-success"></i> Pelanggan Lunas</strong>
            <span class="badge text-bg-success"><?php echo e($paidInvoices->count()); ?> tagihan</span>
        </div>
        <div class="table-responsive">
        <table class="table table-sm mb-0">
            <thead class="table-light"><tr><th>Pelanggan</th><th>Dusun</th><th>Periode</th><th class="text-end">Nominal</th><th class="text-end">Dibayar</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $paidInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($inv->customer->name); ?> <span class="text-muted small"><?php echo e($inv->customer->customer_code); ?></span></td>
                <td><?php echo e($inv->customer->dusun ?: '-'); ?></td>
                <td><?php echo e(format_period($inv->billing_period)); ?></td>
                <td class="text-end"><?php echo e(format_rupiah($inv->amount)); ?></td>
                <td class="text-end text-success fw-semibold"><?php echo e(format_rupiah($inv->paid_amount)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-center text-muted py-3">Belum ada pelanggan lunas.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/reports/index.blade.php ENDPATH**/ ?>