<?php $__env->startSection('title', 'Pelanggan per Dusun'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <h4 class="mb-0"><i class="bi bi-diagram-3"></i> Pelanggan per Dusun</h4>
    <div class="btn-group">
        <a href="<?php echo e(route('dusun.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-geo-alt"></i> Kelola Dusun</a>
        <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-outline-secondary"><i class="bi bi-list-ul"></i> Tampilan Daftar</a>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-12 col-md-6">
                <label class="form-label small">Cari</label>
                <input type="text" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" class="form-control" placeholder="Kode / nama / telepon / alamat">
            </div>
            <div class="col-6 col-md-3">
                <label class="form-label small">Dusun</label>
                <select name="dusun" class="form-select">
                    <option value="">Semua Dusun</option>
                    <?php $__currentLoopData = $dusunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d); ?>" <?php if(($filters['dusun'] ?? '') === $d): echo 'selected'; endif; ?>><?php echo e($d); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-6 col-md-3 d-grid">
                <button class="btn btn-outline-primary"><i class="bi bi-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<?php if($dusunList->isNotEmpty()): ?>
    <div class="row g-2 mb-3">
        <?php $__currentLoopData = $dusunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $info = $summary[$d] ?? ['total' => 0, 'active' => 0]; ?>
            <div class="col-6 col-md-4 col-lg-3">
                <a href="<?php echo e(route('customers.by-dusun', ['dusun' => $d])); ?>" class="text-decoration-none">
                    <div class="card stat-card h-100 <?php echo e(($filters['dusun'] ?? '') === $d ? 'border-primary border-2' : ''); ?>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start">
                                <div class="small text-muted">Dusun</div>
                                <i class="bi bi-geo-alt text-primary"></i>
                            </div>
                            <div class="stat-value text-truncate" title="<?php echo e($d); ?>"><?php echo e($d); ?></div>
                            <div class="small">
                                <span class="badge text-bg-primary"><?php echo e($info['total']); ?> pelanggan</span>
                                <span class="badge text-bg-success"><?php echo e($info['active']); ?> aktif</span>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>

<?php if($grouped->isEmpty()): ?>
    <div class="card"><div class="card-body text-center text-muted py-4">Belum ada data pelanggan.</div></div>
<?php else: ?>
    <div class="accordion" id="dusunAccordion">
        <?php $__currentLoopData = $grouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dusun => $customers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $active = $customers->where('status', 'active')->count();
                $collapseId = 'dusun-'.md5($dusun);
                $open = (count($grouped) === 1) || (($filters['dusun'] ?? '') !== '');
            ?>
            <div class="accordion-item">
                <h2 class="accordion-header">
                    <button class="accordion-button <?php echo e($open ? '' : 'collapsed'); ?>" type="button" data-bs-toggle="collapse" data-bs-target="#<?php echo e($collapseId); ?>" <?php if(!$open): ?> aria-expanded="false" <?php endif; ?>>
                        <span class="me-2"><i class="bi bi-geo-alt-fill text-primary"></i></span>
                        <strong><?php echo e($dusun); ?></strong>
                        <span class="badge text-bg-secondary ms-2"><?php echo e($customers->count()); ?></span>
                        <span class="badge text-bg-success ms-1"><?php echo e($active); ?> aktif</span>
                    </button>
                </h2>
                <div id="<?php echo e($collapseId); ?>" class="accordion-collapse collapse <?php echo e($open ? 'show' : ''); ?>" data-bs-parent="#dusunAccordion">
                    <div class="accordion-body p-0">
                        <div class="table-responsive">
                            <table class="table table-sm table-hover align-middle mb-0">
                                <thead class="table-light">
                                    <tr><th>Kode</th><th>Nama</th><th>Telepon</th><th>Paket</th><th>Tarif</th><th>Status</th><th class="text-end">Aksi</th></tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><strong><?php echo e($c->customer_code); ?></strong></td>
                                            <td><?php echo e($c->name); ?><div class="small text-muted text-truncate" style="max-width:220px"><?php echo e($c->address); ?></div></td>
                                            <td><?php echo e($c->phone ?: '-'); ?></td>
                                            <td><?php echo e($c->package?->name ?? '-'); ?></td>
                                            <td><?php echo e(format_rupiah($c->monthly_fee)); ?></td>
                                            <td><span class="badge <?php echo e($c->status === 'active' ? 'bg-success-subtle text-success-emphasis' : ($c->status === 'suspended' ? 'bg-warning-subtle text-warning-emphasis' : 'bg-secondary-subtle text-secondary-emphasis')); ?>"><?php echo e($c->status->label()); ?></span></td>
                                            <td class="text-end text-nowrap">
                                                <a href="<?php echo e(route('customers.show', $c)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
                                                <a href="<?php echo e(route('customers.edit', $c)); ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/customers/by-dusun.blade.php ENDPATH**/ ?>