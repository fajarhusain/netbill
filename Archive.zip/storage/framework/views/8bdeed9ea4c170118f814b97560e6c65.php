<?php $__env->startSection('title', $customer->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h4 class="mb-0"><?php echo e($customer->name); ?></h4>
        <p class="text-muted small mb-0"><?php echo e($customer->customer_code); ?> &middot; <span class="badge <?php echo e($customer->status === 'active' ? 'bg-success-subtle text-success-emphasis' : ($customer->status === 'suspended' ? 'bg-warning-subtle text-warning-emphasis' : 'bg-secondary-subtle text-secondary-emphasis')); ?>"><?php echo e($customer->status->label()); ?></span></p>
    </div>
    <div class="btn-group">
        <a href="<?php echo e(route('customers.card', $customer)); ?>" class="btn btn-outline-primary"><i class="bi bi-qr-code"></i> Kartu</a>
        <a href="<?php echo e(route('customers.edit', $customer)); ?>" class="btn btn-outline-warning"><i class="bi bi-pencil"></i> Edit</a>
        <a href="<?php echo e(route('scan.customer', $customer)); ?>" class="btn btn-success"><i class="bi bi-cash"></i> Tagih/Bayar</a>
        <form action="<?php echo e(route('customers.destroy', $customer)); ?>" method="POST" id="deleteForm" class="d-inline"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?></form>
        <button type="button" class="btn btn-outline-danger" onclick="confirmDeleteCustomer()"><i class="bi bi-trash"></i> Hapus</button>
    </div>
</div>

<div class="row g-3">
    <div class="col-12 col-lg-4">
        <div class="card mb-3">
            <div class="card-header bg-white"><strong>Informasi Pelanggan</strong></div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <img src="<?php echo e(route('customers.qrcode', $customer)); ?>" alt="QR" class="img-fluid" style="max-width:200px;">
                    <div class="small text-muted mt-1">Token: <?php echo e(Illuminate\Support\Str::limit($customer->barcode_token, 12, '…')); ?></div>
                </div>
                <dl class="row mb-0 small">
                    <dt class="col-5">Kode</dt><dd class="col-7"><?php echo e($customer->customer_code); ?></dd>
                    <dt class="col-5">WhatsApp</dt><dd class="col-7"><?php echo e($customer->phone ?: '-'); ?></dd>
                    <dt class="col-5">Paket</dt><dd class="col-7"><?php echo e($customer->package?->name ?? '-'); ?></dd>
                    <dt class="col-5">Tarif</dt><dd class="col-7"><?php echo e(format_rupiah($customer->monthly_fee)); ?></dd>
                    <dt class="col-5">Mulai</dt><dd class="col-7"><?php echo e(format_date($customer->started_at)); ?></dd>
                    <dt class="col-5">Jatuh Tempo</dt><dd class="col-7">Tanggal <?php echo e($customer->due_day); ?></dd>
                    <dt class="col-5">Alamat</dt><dd class="col-7"><?php echo e($customer->address ?: '-'); ?></dd>
                    <dt class="col-5">Dusun</dt><dd class="col-7"><?php echo e($customer->dusun ?: '-'); ?></dd>
                    <?php if($customer->notes): ?><dt class="col-5">Catatan</dt><dd class="col-7"><?php echo e($customer->notes); ?></dd><?php endif; ?>
                </dl>
                <form action="<?php echo e(route('customers.regenerate', $customer)); ?>" method="POST" onsubmit="return confirm('Buat ulang token barcode? Kartu lama tidak berlaku.')">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-sm btn-outline-secondary w-100 mt-2"><i class="bi bi-arrow-repeat"></i> Buat Ulang Barcode</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-8">
        <div class="card mb-3">
            <div class="card-header bg-white"><strong>Tagihan</strong></div>
            <div class="table-responsive">
                <table class="table table-sm align-middle mb-0">
                    <thead class="table-light"><tr><th>Periode</th><th>Nominal</th><th>Dibayar</th><th>Sisa</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $customer->invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e(format_period($inv->billing_period)); ?></td>
                            <td><?php echo e(format_rupiah($inv->amount)); ?></td>
                            <td><?php echo e(format_rupiah($inv->paid_amount)); ?></td>
                            <td class="text-danger"><?php echo e(format_rupiah($inv->balance())); ?></td>
                            <td><span class="badge <?php echo e($inv->status->badgeClass()); ?>"><?php echo e($inv->status->label()); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="text-center text-muted py-3">Belum ada tagihan.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-white"><strong>Riwayat Pembayaran</strong></div>
            <div class="table-responsive">
                <table class="table table-sm align-middle mb-0">
                    <thead class="table-light"><tr><th>No. Transaksi</th><th>Tanggal</th><th>Nominal</th><th>Metode</th><th>Status</th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $customer->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('payments.show', $p)); ?>"><?php echo e($p->transaction_number); ?></a></td>
                            <td class="small"><?php echo e(format_datetime($p->paid_at)); ?></td>
                            <td><?php echo e(format_rupiah($p->amount_received)); ?></td>
                            <td><?php echo e($p->payment_method->label()); ?></td>
                            <td><span class="badge <?php echo e($p->status->badgeClass()); ?>"><?php echo e($p->status->label()); ?></span></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="text-center text-muted py-3">Belum ada pembayaran.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDeleteCustomer() {
    Swal.fire({
        icon: 'warning',
        title: 'Hapus Pelanggan?',
        html: 'Pelanggan <strong><?php echo e(addslashes($customer->name)); ?></strong> akan dihapus permanen.<br>Pelanggan dengan transaksi pembayaran tidak dapat dihapus.',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#64748b',
    }).then(function (result) {
        if (result.isConfirmed) {
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/customers/show.blade.php ENDPATH**/ ?>