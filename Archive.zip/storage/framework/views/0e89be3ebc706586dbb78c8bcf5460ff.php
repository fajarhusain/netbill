<?php $__env->startSection('title', 'Setoran Petugas'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <h4 class="mb-0"><i class="bi bi-bank"></i> <?php echo e(auth()->user()->isAdmin() ? 'Setoran Petugas' : 'Setoran Saya'); ?></h4>
    <a href="<?php echo e(route('settlements.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Catat Setoran</a>
</div>

<div class="card bg-warning-subtle border-warning mb-3"><div class="card-body d-flex justify-content-between align-items-center">
    <div><i class="bi bi-wallet2"></i> Kas tunai belum disetor</div>
    <div class="fw-bold fs-5"><?php echo e(format_rupiah($pendingCash)); ?></div>
</div></div>

<div class="card"><div class="table-responsive">
<table class="table table-hover align-middle mb-0">
<thead class="table-light"><tr><th>Tanggal</th><?php if(auth()->user()->isAdmin()): ?><th>Petugas</th><?php endif; ?><th>Diharapkan</th><th>Diterima</th><th>Selisih</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $settlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td><?php echo e(format_date($s->settlement_date)); ?></td>
    <?php if(auth()->user()->isAdmin()): ?><td><?php echo e($s->collector->name); ?></td><?php endif; ?>
    <td><?php echo e(format_rupiah($s->expected_amount)); ?></td>
    <td><?php echo e(format_rupiah($s->received_amount)); ?></td>
    <td class="<?php echo e($s->difference_amount < 0 ? 'text-danger' : ($s->difference_amount > 0 ? 'text-success' : '')); ?>"><?php echo e(format_rupiah($s->difference_amount)); ?></td>
    <td><?php if($s->isConfirmed()): ?><span class="badge bg-success-subtle text-success-emphasis">Dikonfirmasi</span><?php else: ?><span class="badge bg-warning-subtle text-warning-emphasis">Menunggu</span><?php endif; ?></td>
    <td class="text-end"><a href="<?php echo e(route('settlements.show', $s)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="<?php echo e(auth()->user()->isAdmin() ? 7 : 6); ?>" class="text-center text-muted py-4">Belum ada setoran.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<?php if($settlements->hasPages()): ?><div class="card-footer bg-white"><?php echo e($settlements->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill-collector/resources/views/settlements/index.blade.php ENDPATH**/ ?>