<?php $__env->startSection('title', 'Data Pelanggan'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <h4 class="mb-0"><i class="bi bi-people"></i> Data Pelanggan</h4>
    <div class="btn-group">
        <a href="<?php echo e(route('dusun.index')); ?>" class="btn btn-outline-secondary" title="Kelola daftar dusun"><i class="bi bi-geo-alt"></i> Kelola Dusun</a>
        <a href="<?php echo e(route('customers.by-dusun')); ?>" class="btn btn-outline-secondary"><i class="bi bi-diagram-3"></i> Per Dusun</a>
        <button class="btn btn-outline-success" data-bs-toggle="modal" data-bs-target="#importModal"><i class="bi bi-file-earmark-arrow-up"></i> Import Excel</button>
        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Pelanggan</a>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form method="GET" class="row g-2 align-items-end">
            <div class="col-12 col-md-4">
                <label class="form-label small">Cari</label>
                <input type="text" name="q" value="<?php echo e($filters['q'] ?? ''); ?>" class="form-control" placeholder="Kode / nama / telepon">
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label small">Status</label>
                <select name="status" class="form-select">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->value); ?>" <?php if(($filters['status'] ?? '') === $s->value): echo 'selected'; endif; ?>><?php echo e($s->label()); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label small">Paket</label>
                <select name="package_id" class="form-select">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>" <?php if(($filters['package_id'] ?? '') == $p->id): echo 'selected'; endif; ?>><?php echo e($p->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-6 col-md-2">
                <label class="form-label small">Dusun</label>
                <select name="dusun" class="form-select">
                    <option value="">Semua</option>
                    <?php $__currentLoopData = $dusunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($d); ?>" <?php if(($filters['dusun'] ?? '') === $d): echo 'selected'; endif; ?>><?php echo e($d); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-12 col-md-2 d-grid">
                <button class="btn btn-outline-primary"><i class="bi bi-search"></i> Filter</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Kode</th><th>Nama</th><th>Paket</th><th>Tarif</th><th>Jatuh Tempo</th><th>Status</th><th class="text-end">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><strong><?php echo e($c->customer_code); ?></strong></td>
                    <td><?php echo e($c->name); ?><div class="small text-muted"><?php echo e($c->phone); ?></div></td>
                    <td><?php echo e($c->package?->name ?? '-'); ?></td>
                    <td><?php echo e(format_rupiah($c->monthly_fee)); ?></td>
                    <td>Tgl <?php echo e($c->due_day); ?></td>
                    <td><span class="badge <?php echo e($c->status === 'active' ? 'bg-success-subtle text-success-emphasis' : ($c->status === 'suspended' ? 'bg-warning-subtle text-warning-emphasis' : 'bg-secondary-subtle text-secondary-emphasis')); ?>"><?php echo e($c->status->label()); ?></span></td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('customers.show', $c)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
                        <a href="<?php echo e(route('customers.card', $c)); ?>" class="btn btn-sm btn-outline-primary" title="Kartu QR"><i class="bi bi-qr-code"></i></a>
                        <a href="<?php echo e(route('customers.edit', $c)); ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                        <form action="<?php echo e(route('customers.destroy', $c)); ?>" method="POST" class="d-inline" id="deleteForm-<?php echo e($c->id); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        </form>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="confirmDeleteCustomer(<?php echo e($c->id); ?>, '<?php echo e(addslashes($c->name)); ?>')"><i class="bi bi-trash"></i></button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">Belum ada data pelanggan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($customers->hasPages()): ?>
    <div class="card-footer bg-white"><?php echo e($customers->links()); ?></div>
    <?php endif; ?>
</div>

<div class="modal fade" id="importModal" tabindex="-1">
<div class="modal-dialog"><div class="modal-content">
<form method="POST" action="<?php echo e(route('customers.import')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>
    <div class="modal-header"><h5 class="modal-title"><i class="bi bi-file-earmark-arrow-up"></i> Import Pelanggan dari Excel</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body">
        <div class="alert alert-info small mb-3">
            <i class="bi bi-info-circle"></i> Unduh template terlebih dahulu, isi data pelanggan, lalu unggah kembali.
            Format mendukung <strong>.xlsx</strong>, <strong>.xls</strong>, dan <strong>.csv</strong>.
        </div>
        <a href="<?php echo e(route('customers.import.template')); ?>" class="btn btn-outline-primary btn-sm mb-3"><i class="bi bi-download"></i> Unduh Template Excel</a>
        <label class="form-label">Pilih File <span class="text-danger">*</span></label>
        <input type="file" name="file" class="form-control" accept=".xlsx,.xls,.csv" required>
        <div class="form-text small mt-2">
            Kolom: <strong>nama</strong> (wajib), kode, telepon, alamat, dusun, paket, <strong>tarif</strong> (wajib),
            tanggal_mulai, tanggal_jatuh_tempo, status, catatan.
        </div>
    </div>
    <div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button><button class="btn btn-success"><i class="bi bi-upload"></i> Import</button></div>
</form></div></div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDeleteCustomer(id, name) {
    Swal.fire({
        icon: 'warning',
        title: 'Hapus Pelanggan?',
        html: 'Pelanggan <strong>' + name + '</strong> akan dihapus permanen.<br>Pelanggan dengan transaksi pembayaran tidak dapat dihapus.',
        showCancelButton: true,
        confirmButtonText: 'Ya, Hapus',
        cancelButtonText: 'Batal',
        confirmButtonColor: '#dc3545',
        cancelButtonColor: '#64748b',
    }).then(function (result) {
        if (result.isConfirmed) {
            document.getElementById('deleteForm-' + id).submit();
        }
    });
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/customers/index.blade.php ENDPATH**/ ?>