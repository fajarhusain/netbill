<?php $__env->startSection('title', 'Riwayat Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-cash-stack"></i> <?php echo e(auth()->user()->isAdmin() ? 'Transaksi' : 'Riwayat Transaksi Saya'); ?></h4>
</div>

<div class="card mb-3"><div class="card-body">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-12 col-md-3">
        <label class="form-label small">Cari</label>
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="No. transaksi / pelanggan">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small">Dari</label>
        <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="form-control">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small">Sampai</label>
        <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="form-control">
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small">Metode</label>
        <select name="method" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($m->value); ?>" <?php if(request('method')===$m->value): echo 'selected'; endif; ?>><?php echo e($m->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <div class="col-6 col-md-2">
        <label class="form-label small">Status</label>
        <select name="status" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s->value); ?>" <?php if(request('status')===$s->value): echo 'selected'; endif; ?>><?php echo e($s->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <?php if(auth()->user()->isAdmin() && $collectors->isNotEmpty()): ?>
    <div class="col-6 col-md-3">
        <label class="form-label small">Petugas</label>
        <select name="collector_id" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $collectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php if(request('collector_id')==$c->id): echo 'selected'; endif; ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <?php endif; ?>
    <div class="col-12 col-md-1 d-grid"><button class="btn btn-outline-primary"><i class="bi bi-search"></i></button></div>
</form>
</div></div>

<div class="card">
<div class="table-responsive">
<table class="table table-hover align-middle mb-0">
<thead class="table-light"><tr><th>No. Transaksi</th><th>Pelanggan</th><th>Nominal</th><th>Metode</th><th>Petugas</th><th>Waktu</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td><strong><?php echo e($p->transaction_number); ?></strong></td>
    <td><?php echo e($p->customer->name); ?><div class="small text-muted"><?php echo e($p->customer->customer_code); ?></div></td>
    <td><?php echo e(format_rupiah($p->amount_received)); ?></td>
    <td><?php echo e($p->payment_method->label()); ?></td>
    <td><?php echo e($p->collector->name); ?></td>
    <td class="small"><?php echo e(format_datetime($p->paid_at)); ?></td>
    <td><span class="badge <?php echo e($p->status->badgeClass()); ?>"><?php echo e($p->status->label()); ?></span></td>
    <td class="text-end text-nowrap">
        <a href="<?php echo e(route('payments.show', $p)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
        <a href="<?php echo e(route('payments.receipt', $p)); ?>" class="btn btn-sm btn-outline-primary" title="Bukti"><i class="bi bi-receipt"></i></a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="8" class="text-center text-muted py-4">Belum ada transaksi.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<?php if($payments->hasPages()): ?><div class="card-footer bg-white"><?php echo e($payments->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill-collector/resources/views/payments/index.blade.php ENDPATH**/ ?>