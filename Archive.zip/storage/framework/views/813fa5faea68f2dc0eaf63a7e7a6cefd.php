<?php $__env->startSection('title', 'Manajemen Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-person-gear"></i> Pengguna</h4>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah</a>
</div>
<div class="card mb-3"><div class="card-body">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-md-6"><label class="form-label small">Cari</label><input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"></div>
    <div class="col-md-4"><label class="form-label small">Role</label><select name="role" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($r->value); ?>" <?php if(request('role')===$r->value): echo 'selected'; endif; ?>><?php echo e($r->label()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="col-md-2 d-grid"><button class="btn btn-outline-primary"><i class="bi bi-search"></i></button></div>
</form>
</div></div>
<div class="card"><div class="table-responsive">
<table class="table table-hover align-middle mb-0">
<thead class="table-light"><tr><th>Nama</th><th>Username</th><th>Role</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td><?php echo e($u->name); ?></td>
    <td><?php echo e($u->username); ?></td>
    <td><span class="badge <?php echo e($u->isAdmin() ? 'bg-primary' : 'bg-info text-dark'); ?>"><?php echo e($u->role->label()); ?></span></td>
    <td><?php if($u->is_active): ?><span class="badge bg-success-subtle text-success-emphasis">Aktif</span><?php else: ?><span class="badge bg-secondary-subtle text-secondary-emphasis">Nonaktif</span><?php endif; ?></td>
    <td class="text-end"><a href="<?php echo e(route('users.show', $u)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a> <a href="<?php echo e(route('users.edit', $u)); ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="5" class="text-center text-muted py-4">Belum ada pengguna.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<?php if($users->hasPages()): ?><div class="card-footer bg-white"><?php echo e($users->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/users/index.blade.php ENDPATH**/ ?>