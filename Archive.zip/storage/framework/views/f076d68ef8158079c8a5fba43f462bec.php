<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Nama Paket <span class="text-danger">*</span></label>
        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name', $package->name ?? '')); ?>" required>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6">
        <label class="form-label">Kecepatan</label>
        <input type="text" name="speed" class="form-control" value="<?php echo e(old('speed', $package->speed ?? '')); ?>" placeholder="mis. 10 Mbps">
    </div>
    <div class="col-md-6">
        <label class="form-label">Tarif Bulanan (Rp) <span class="text-danger">*</span></label>
        <input type="number" name="monthly_price" class="form-control <?php $__errorArgs = ['monthly_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('monthly_price', $package->monthly_price ?? '')); ?>" min="0" required>
        <div class="form-text small">Perubahan tarif tidak mengubah nominal tagihan lama.</div>
        <?php $__errorArgs = ['monthly_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-6 d-flex align-items-end">
        <div class="form-check">
            <input type="checkbox" name="is_active" value="1" class="form-check-input" id="is_active" <?php echo e(old('is_active', isset($package) ? $package->is_active : true) ? 'checked' : ''); ?>>
            <label class="form-check-label" for="is_active">Aktif</label>
        </div>
    </div>
    <div class="col-12">
        <label class="form-label">Deskripsi</label>
        <textarea name="description" class="form-control" rows="2"><?php echo e(old('description', $package->description ?? '')); ?></textarea>
    </div>
    <div class="col-12">
        <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button>
        <a href="<?php echo e(route('packages.index')); ?>" class="btn btn-outline-secondary">Batal</a>
    </div>
</div>
<?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/packages/_form.blade.php ENDPATH**/ ?>