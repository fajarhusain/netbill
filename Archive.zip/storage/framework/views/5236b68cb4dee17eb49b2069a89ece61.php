<?php $__env->startSection('title', 'Audit Log'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-clock-history"></i> Audit Log</h4>
</div>
<div class="card mb-3"><div class="card-body">
<form method="GET" class="row g-2 align-items-end">
    <div class="col-md-4"><label class="form-label small">Cari Alasan</label><input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control"></div>
    <div class="col-md-3"><label class="form-label small">Aksi</label><select name="action" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($a); ?>" <?php if(request('action')===$a): echo 'selected'; endif; ?>><?php echo e($a); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="col-md-3"><label class="form-label small">Entitas</label><select name="entity_type" class="form-select"><option value="">Semua</option><?php $__currentLoopData = $entityTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($e); ?>" <?php if(request('entity_type')===$e): echo 'selected'; endif; ?>><?php echo e($e); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="col-md-2 d-grid"><button class="btn btn-outline-primary"><i class="bi bi-search"></i></button></div>
</form>
</div></div>
<div class="card"><div class="table-responsive">
<table class="table table-sm align-middle mb-0">
<thead class="table-light"><tr><th>Waktu</th><th>User</th><th>Aksi</th><th>Entitas</th><th>Alasan</th></tr></thead>
<tbody>
<?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td class="small"><?php echo e(format_datetime($l->created_at)); ?></td>
    <td><?php echo e($l->user?->name ?? 'Sistem'); ?></td>
    <td><code><?php echo e($l->action); ?></code></td>
    <td class="small"><?php echo e($l->entity_type ? $l->entity_type.' #'.$l->entity_id : '-'); ?></td>
    <td class="small"><?php echo e($l->reason ?: '-'); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr><td colspan="5" class="text-center text-muted py-4">Belum ada catatan audit.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<?php if($logs->hasPages()): ?><div class="card-footer bg-white"><?php echo e($logs->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/audit/index.blade.php ENDPATH**/ ?>