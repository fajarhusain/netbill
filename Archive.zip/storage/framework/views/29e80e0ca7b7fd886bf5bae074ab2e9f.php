<?php $__env->startSection('title', $payment->transaction_number); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h4 class="mb-0"><?php echo e($payment->transaction_number); ?></h4>
        <p class="text-muted small mb-0"><?php echo e(format_datetime($payment->paid_at)); ?></p>
    </div>
    <div class="btn-group">
        <a href="<?php echo e(route('payments.receipt', $payment)); ?>" class="btn btn-outline-primary"><i class="bi bi-receipt"></i> Lihat Bukti</a>
        <a href="<?php echo e(route('payments.pdf', $payment)); ?>" class="btn btn-outline-secondary"><i class="bi bi-file-pdf"></i> PDF</a>
        <?php if(auth()->user()->isAdmin() && !$payment->isCancelled()): ?>
        <button class="btn btn-outline-danger" data-bs-toggle="modal" data-bs-target="#cancelModal"><i class="bi bi-x-circle"></i> Batalkan</button>
        <?php endif; ?>
    </div>
</div>

<?php if($payment->isCancelled()): ?>
<div class="alert alert-danger"><strong>Dibatalkan.</strong> <?php echo e($payment->cancellation_reason); ?> <div class="small">oleh <?php echo e($payment->cancelledBy?->name); ?> pada <?php echo e(format_datetime($payment->cancelled_at)); ?></div></div>
<?php endif; ?>

<div class="row g-3">
<div class="col-md-6">
    <div class="card"><div class="card-header bg-white"><strong>Detail Transaksi</strong></div><div class="card-body">
        <dl class="row mb-0">
            <dt class="col-5">No. Transaksi</dt><dd class="col-7"><?php echo e($payment->transaction_number); ?></dd>
            <dt class="col-5">Pelanggan</dt><dd class="col-7"><?php echo e($payment->customer->name); ?> (<?php echo e($payment->customer->customer_code); ?>)</dd>
            <dt class="col-5">Petugas</dt><dd class="col-7"><?php echo e($payment->collector->name); ?></dd>
            <dt class="col-5">Waktu</dt><dd class="col-7"><?php echo e(format_datetime($payment->paid_at)); ?></dd>
            <dt class="col-5">Nominal</dt><dd class="col-7"><?php echo e(format_rupiah($payment->amount_received)); ?></dd>
            <dt class="col-5">Metode</dt><dd class="col-7"><?php echo e($payment->payment_method->label()); ?></dd>
            <dt class="col-5">Status</dt><dd class="col-7"><span class="badge <?php echo e($payment->status->badgeClass()); ?>"><?php echo e($payment->status->label()); ?></span></dd>
            <?php if($payment->notes): ?><dt class="col-5">Catatan</dt><dd class="col-7"><?php echo e($payment->notes); ?></dd><?php endif; ?>
        </dl>
    </div></div>
</div>
<div class="col-md-6">
    <div class="card"><div class="card-header bg-white"><strong>Alokasi ke Tagihan</strong></div>
    <div class="table-responsive">
    <?php if($payment->allocations->isEmpty()): ?>
        <div class="p-4 text-center text-muted small">Tidak ada alokasi.</div>
    <?php else: ?>
        <table class="table table-sm mb-0">
        <thead class="table-light"><tr><th>Periode</th><th>Nominal Tagihan</th><th>Dialokasikan</th><th>Sisa</th></tr></thead>
        <tbody>
        <?php $__currentLoopData = $payment->allocations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(format_period($a->invoice->billing_period)); ?></td>
            <td><?php echo e(format_rupiah($a->invoice->amount)); ?></td>
            <td class="fw-semibold"><?php echo e(format_rupiah($a->amount_allocated)); ?></td>
            <td><?php echo e(format_rupiah($a->invoice->balance())); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    <?php endif; ?>
    </div></div>
</div>
</div>

<div class="modal fade" id="cancelModal" tabindex="-1"><div class="modal-dialog"><div class="modal-content">
<form method="POST" action="<?php echo e(route('payments.cancel', $payment)); ?>"><?php echo csrf_field(); ?>
<div class="modal-header"><h5 class="modal-title">Batalkan Transaksi</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
<div class="modal-body">
    <div class="alert alert-warning small">Pembatalan akan mengembalikan status tagihan seperti semula. Tindakan ini tercatat di audit log.</div>
    <label class="form-label">Alasan <span class="text-danger">*</span></label>
    <textarea name="reason" class="form-control" rows="3" required minlength="5"></textarea>
</div>
<div class="modal-footer"><button class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button><button class="btn btn-danger">Batalkan Transaksi</button></div>
</form></div></div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/payments/show.blade.php ENDPATH**/ ?>