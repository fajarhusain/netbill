<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
    <div>
        <h4 class="mb-0">Dashboard</h4>
        <p class="text-muted small mb-0"><?php echo e(format_datetime($now)); ?></p>
    </div>
    <?php if(auth()->user()->isAdmin()): ?>
    <div class="btn-group">
        <a href="<?php echo e(route('scan.index')); ?>" class="btn btn-primary"><i class="bi bi-qr-code-scan"></i> Scan</a>
        <a href="<?php echo e(route('invoices.create')); ?>" class="btn btn-outline-primary"><i class="bi bi-file-text"></i> Buat Tagihan</a>
    </div>
    <?php else: ?>
    <a href="<?php echo e(route('scan.index')); ?>" class="btn btn-primary btn-lg"><i class="bi bi-qr-code-scan"></i> Mulai Scan</a>
    <?php endif; ?>
</div>

<div class="row g-3 mb-4">
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card stat-card h-100">
            <div class="card-body">
                <div class="text-muted small"><i class="bi bi-people"></i> Total Pelanggan</div>
                <div class="stat-value"><?php echo e(number_format($totalCustomers)); ?></div>
                <div class="small text-success"><?php echo e($activeCustomers); ?> aktif</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card stat-card h-100">
            <div class="card-body">
                <div class="text-muted small"><i class="bi bi-file-text"></i> Tagihan <?php echo e(format_period($currentPeriod)); ?></div>
                <div class="stat-value"><?php echo e(format_rupiah($totalInvoicedCurrentPeriod)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card stat-card h-100">
            <div class="card-body">
                <div class="text-muted small"><i class="bi bi-cash-coin"></i> Penerimaan Hari Ini</div>
                <div class="stat-value text-success"><?php echo e(format_rupiah($paidToday)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card stat-card h-100">
            <div class="card-body">
                <div class="text-muted small"><i class="bi bi-graph-up"></i> Penerimaan Bulan Ini</div>
                <div class="stat-value"><?php echo e(format_rupiah($paidThisMonth)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card stat-card h-100">
            <div class="card-body">
                <div class="text-muted small"><i class="bi bi-exclamation-triangle"></i> Total Tunggakan</div>
                <div class="stat-value text-danger"><?php echo e(format_rupiah($arrearsTotal)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card stat-card h-100">
            <div class="card-body">
                <div class="text-muted small"><i class="bi bi-person-x"></i> Pelanggan Belum Bayar</div>
                <div class="stat-value"><?php echo e(number_format($unpaidCustomerCount)); ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card stat-card h-100">
            <div class="card-body">
                <div class="text-muted small"><i class="bi bi-geo-alt"></i> Kunjungan Hari Ini</div>
                <div class="stat-value"><?php echo e($visitsToday); ?></div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card stat-card h-100">
            <div class="card-body">
                <div class="text-muted small"><i class="bi bi-wallet2"></i> Kas Belum Disetor</div>
                <div class="stat-value text-warning"><?php echo e(format_rupiah($pendingSettlement)); ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-12 col-lg-7">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center bg-white">
                <strong><i class="bi bi-clock-history"></i> Transaksi Terbaru</strong>
                <?php if(auth()->user()->isAdmin()): ?>
                <a href="<?php echo e(route('payments.index')); ?>" class="small text-decoration-none">Lihat semua</a>
                <?php else: ?>
                <a href="<?php echo e(route('payments.index')); ?>" class="small text-decoration-none">Riwayat saya</a>
                <?php endif; ?>
            </div>
            <div class="card-body p-0">
                <?php if($recentPayments->isEmpty()): ?>
                    <div class="p-4 text-center text-muted small">Belum ada transaksi.</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>No. Transaksi</th><th>Pelanggan</th><th>Nominal</th><th>Waktu</th></tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $recentPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('payments.show', $p)); ?>" class="text-decoration-none"><?php echo e($p->transaction_number); ?></a></td>
                                <td><?php echo e($p->customer->name); ?><div class="small text-muted"><?php echo e($p->customer->customer_code); ?></div></td>
                                <td class="fw-semibold"><?php echo e(format_rupiah($p->amount_received)); ?></td>
                                <td class="small"><?php echo e(format_datetime($p->paid_at)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-5">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center bg-white">
                <strong><i class="bi bi-exclamation-circle"></i> Tunggakan Terbaru</strong>
                <?php if(auth()->user()->isAdmin()): ?>
                <a href="<?php echo e(route('invoices.index')); ?>" class="small text-decoration-none">Lihat semua</a>
                <?php endif; ?>
            </div>
            <div class="card-body p-0">
                <?php if($arrears->isEmpty()): ?>
                    <div class="p-4 text-center text-muted small">Tidak ada tunggakan.</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr><th>Pelanggan</th><th>Periode</th><th>Sisa</th></tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($inv->customer->name); ?><div class="small text-muted"><?php echo e($inv->customer->customer_code); ?></div></td>
                                <td><?php echo e(format_period($inv->billing_period)); ?></td>
                                <td class="fw-semibold text-danger"><?php echo e(format_rupiah($inv->balance())); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill-collector/resources/views/dashboard.blade.php ENDPATH**/ ?>