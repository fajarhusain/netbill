<?php $__env->startSection('title', 'Paket Internet'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-boxes"></i> Paket Internet</h4>
    <a href="<?php echo e(route('packages.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Paket</a>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Nama</th><th>Kecepatan</th><th>Tarif</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($p->name); ?></td>
                    <td><?php echo e($p->speed ?: '-'); ?></td>
                    <td><?php echo e(format_rupiah($p->monthly_price)); ?></td>
                    <td><?php if($p->is_active): ?><span class="badge bg-success-subtle text-success-emphasis">Aktif</span><?php else: ?><span class="badge bg-secondary-subtle text-secondary-emphasis">Nonaktif</span><?php endif; ?></td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('packages.show', $p)); ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-eye"></i></a>
                        <a href="<?php echo e(route('packages.edit', $p)); ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                        <form action="<?php echo e(route('packages.destroy', $p)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus paket?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button></form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center text-muted py-4">Belum ada paket.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($packages->hasPages()): ?><div class="card-footer bg-white"><?php echo e($packages->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/packages/index.blade.php ENDPATH**/ ?>