<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<style>
    * { font-family: DejaVu Sans, sans-serif; }
    body { color: #222; font-size: 12px; margin: 0; }
    .header { text-align: center; border-bottom: 2px solid #0d6efd; padding-bottom: 8px; margin-bottom: 12px; }
    .header h1 { font-size: 18px; margin: 0; color: #0d6efd; }
    .header .sub { font-size: 11px; color: #666; margin-top: 2px; }
    .summary { display: table; width: 100%; margin-bottom: 12px; }
    .summary-cell { display: table-cell; width: 33.33%; border: 1px solid #ddd; padding: 8px; text-align: center; }
    .summary-cell .label { font-size: 10px; color: #666; }
    .summary-cell .value { font-size: 16px; font-weight: bold; }
    h2 { font-size: 13px; background: #f0f4ff; padding: 4px 8px; border-left: 3px solid #0d6efd; margin: 14px 0 6px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
    th { background: #f8f9fa; text-align: left; font-size: 10px; padding: 4px 6px; border-bottom: 1px solid #ddd; }
    td { padding: 4px 6px; border-bottom: 1px solid #eee; font-size: 11px; }
    .text-right { text-align: right; }
    .text-danger { color: #dc3545; }
    .text-success { color: #198754; }
    .small { font-size: 10px; color: #666; }
    .footer { margin-top: 20px; text-align: center; font-size: 10px; color: #999; border-top: 1px solid #eee; padding-top: 8px; }
</style>
</head>
<body>
<div class="header">
    <h1>Laporan Keuangan Penagihan</h1>
    <div class="sub">Periode <?php echo e(format_date($dateFrom)); ?> s/d <?php echo e(format_date($dateTo)); ?><?php if($dusun): ?> · Dusun <?php echo e($dusun); ?><?php endif; ?></div>
</div>

<table class="summary">
    <tr>
        <td class="summary-cell">
            <div class="label">Total Penerimaan</div>
            <div class="value text-success"><?php echo e(format_rupiah($totalReceived)); ?></div>
            <div class="small"><?php echo e($totalTransactions); ?> transaksi</div>
        </td>
        <td class="summary-cell">
            <div class="label">Total Tunggakan</div>
            <div class="value text-danger"><?php echo e(format_rupiah($totalArrears)); ?></div>
        </td>
        <td class="summary-cell">
            <div class="label">Pelanggan Aktif</div>
            <div class="value"><?php echo e($customerStats['active']); ?>/<?php echo e($customerStats['total']); ?></div>
            <div class="small"><?php echo e($customerStats['inactive']); ?> nonaktif, <?php echo e($customerStats['suspended']); ?> ditangguhkan</div>
        </td>
    </tr>
</table>

<h2>Per Petugas</h2>
<?php if($byCollector->isEmpty()): ?>
<p class="small">Tidak ada data.</p>
<?php else: ?>
<table>
    <thead><tr><th>Petugas</th><th class="text-right">Transaksi</th><th class="text-right">Total</th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $byCollector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><?php echo e($r->collector->name); ?></td><td class="text-right"><?php echo e($r->tx_count); ?></td><td class="text-right"><?php echo e(format_rupiah($r->total)); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>

<h2>Per Metode Pembayaran</h2>
<?php if($byMethod->isEmpty()): ?>
<p class="small">Tidak ada data.</p>
<?php else: ?>
<table>
    <thead><tr><th>Metode</th><th class="text-right">Transaksi</th><th class="text-right">Total</th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $byMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><?php echo e($r->method->label()); ?></td><td class="text-right"><?php echo e($r->tx_count); ?></td><td class="text-right"><?php echo e(format_rupiah($r->total)); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>

<h2>Setoran & Selisih Kas</h2>
<?php if($cashSettlements->isEmpty()): ?>
<p class="small">Tidak ada setoran.</p>
<?php else: ?>
<table>
    <thead><tr><th>Tanggal</th><th>Petugas</th><th class="text-right">Diharapkan</th><th class="text-right">Diterima</th><th class="text-right">Selisih</th><th>Status</th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $cashSettlements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e(format_date($s->settlement_date)); ?></td>
        <td><?php echo e($s->collector->name); ?></td>
        <td class="text-right"><?php echo e(format_rupiah($s->expected_amount)); ?></td>
        <td class="text-right"><?php echo e(format_rupiah($s->received_amount)); ?></td>
        <td class="text-right <?php echo e($s->difference_amount < 0 ? 'text-danger' : ''); ?>"><?php echo e(format_rupiah($s->difference_amount)); ?></td>
        <td><?php echo e($s->isConfirmed() ? 'Dikonfirmasi' : 'Menunggu'); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>

<h2>Tagihan Belum Lunas (Menunggak)</h2>
<?php if($arrears->isEmpty()): ?>
<p class="small">Tidak ada tunggakan.</p>
<?php else: ?>
<table>
    <thead><tr><th>Pelanggan</th><th>Dusun</th><th>Periode</th><th class="text-right">Nominal</th><th class="text-right">Sisa</th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($inv->customer->name); ?> (<?php echo e($inv->customer->customer_code); ?>)</td>
        <td><?php echo e($inv->customer->dusun ?: '-'); ?></td>
        <td><?php echo e(format_period($inv->billing_period)); ?></td>
        <td class="text-right"><?php echo e(format_rupiah($inv->amount)); ?></td>
        <td class="text-right text-danger"><?php echo e(format_rupiah($inv->balance())); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>

<h2>Tagihan Lunas</h2>
<?php if($paidInvoices->isEmpty()): ?>
<p class="small">Belum ada pelanggan lunas.</p>
<?php else: ?>
<table>
    <thead><tr><th>Pelanggan</th><th>Dusun</th><th>Periode</th><th class="text-right">Nominal</th><th class="text-right">Dibayar</th></tr></thead>
    <tbody>
    <?php $__currentLoopData = $paidInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($inv->customer->name); ?> (<?php echo e($inv->customer->customer_code); ?>)</td>
        <td><?php echo e($inv->customer->dusun ?: '-'); ?></td>
        <td><?php echo e(format_period($inv->billing_period)); ?></td>
        <td class="text-right"><?php echo e(format_rupiah($inv->amount)); ?></td>
        <td class="text-right text-success"><?php echo e(format_rupiah($inv->paid_amount)); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php endif; ?>

<div class="footer">
    Laporan dibuat pada <?php echo e(format_datetime(now())); ?> WIB<br>
    NetBill Collector — Aplikasi Penagihan RT/RW Net
</div>
</body>
</html><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/reports/pdf.blade.php ENDPATH**/ ?>