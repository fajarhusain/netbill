<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="utf-8">

<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets>
<x:ExcelWorksheet><x:Name>Ringkasan</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>
</x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->

</head>
<body>
<table border="1">
    <tr><td colspan="4" style="font-weight:bold;font-size:14px;">Laporan Keuangan Penagihan</td></tr>
    <tr><td colspan="4">Periode <?php echo e(format_date($dateFrom)); ?> s/d <?php echo e(format_date($dateTo)); ?><?php if($dusun): ?> · Dusun <?php echo e($dusun); ?><?php endif; ?></td></tr>
    <tr><td colspan="4"></td></tr>
    <tr style="font-weight:bold;background:#e8f0fe;">
        <td>Total Penerimaan</td><td>Total Transaksi</td><td>Total Tunggakan</td><td>Pelanggan Aktif</td>
    </tr>
    <tr>
        <td><?php echo e(format_rupiah($totalReceived, false)); ?></td>
        <td><?php echo e($totalTransactions); ?></td>
        <td><?php echo e(format_rupiah($totalArrears, false)); ?></td>
        <td><?php echo e($customerStats['active']); ?>/<?php echo e($customerStats['total']); ?></td>
    </tr>
</table>

<br>
<table border="1">
    <tr style="font-weight:bold;background:#f8f9fa;"><td colspan="3">Per Petugas</td></tr>
    <tr style="font-weight:bold;"><td>Petugas</td><td>Transaksi</td><td>Total</td></tr>
    <?php $__empty_1 = true; $__currentLoopData = $byCollector; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr><td><?php echo e($r->collector->name); ?></td><td><?php echo e($r->tx_count); ?></td><td><?php echo e(format_rupiah($r->total, false)); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="3">Tidak ada data.</td></tr>
    <?php endif; ?>
</table>

<br>
<table border="1">
    <tr style="font-weight:bold;background:#f8f9fa;"><td colspan="3">Per Metode Pembayaran</td></tr>
    <tr style="font-weight:bold;"><td>Metode</td><td>Transaksi</td><td>Total</td></tr>
    <?php $__empty_1 = true; $__currentLoopData = $byMethod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr><td><?php echo e($r->method->label()); ?></td><td><?php echo e($r->tx_count); ?></td><td><?php echo e(format_rupiah($r->total, false)); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="3">Tidak ada data.</td></tr>
    <?php endif; ?>
</table>

<br>
<table border="1">
    <tr style="font-weight:bold;background:#f8f9fa;"><td colspan="9">Rincian Transaksi</td></tr>
    <tr style="font-weight:bold;"><td>No Transaksi</td><td>Tanggal</td><td>Pelanggan</td><td>Kode</td><td>Dusun</td><td>Petugas</td><td>Metode</td><td>Nominal</td><td>Status</td></tr>
    <?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($p->transaction_number); ?></td>
        <td><?php echo e(format_datetime($p->paid_at)); ?></td>
        <td><?php echo e($p->customer->name); ?></td>
        <td><?php echo e($p->customer->customer_code); ?></td>
        <td><?php echo e($p->customer->dusun ?: ''); ?></td>
        <td><?php echo e($p->collector->name); ?></td>
        <td><?php echo e($p->payment_method->label()); ?></td>
        <td><?php echo e(format_rupiah($p->amount_received, false)); ?></td>
        <td><?php echo e($p->status->label()); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="9">Tidak ada transaksi.</td></tr>
    <?php endif; ?>
</table>

<br>
<table border="1">
    <tr style="font-weight:bold;background:#fce4e4;"><td colspan="5">Pelanggan Menunggak</td></tr>
    <tr style="font-weight:bold;"><td>Pelanggan</td><td>Kode</td><td>Dusun</td><td>Periode</td><td>Sisa</td></tr>
    <?php $__empty_1 = true; $__currentLoopData = $arrears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($inv->customer->name); ?></td>
        <td><?php echo e($inv->customer->customer_code); ?></td>
        <td><?php echo e($inv->customer->dusun ?: ''); ?></td>
        <td><?php echo e(format_period($inv->billing_period)); ?></td>
        <td><?php echo e(format_rupiah($inv->balance(), false)); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="5">Tidak ada tunggakan.</td></tr>
    <?php endif; ?>
</table>

<br>
<table border="1">
    <tr style="font-weight:bold;background:#e4fce8;"><td colspan="5">Pelanggan Lunas</td></tr>
    <tr style="font-weight:bold;"><td>Pelanggan</td><td>Kode</td><td>Dusun</td><td>Periode</td><td>Dibayar</td></tr>
    <?php $__empty_1 = true; $__currentLoopData = $paidInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($inv->customer->name); ?></td>
        <td><?php echo e($inv->customer->customer_code); ?></td>
        <td><?php echo e($inv->customer->dusun ?: ''); ?></td>
        <td><?php echo e(format_period($inv->billing_period)); ?></td>
        <td><?php echo e(format_rupiah($inv->paid_amount, false)); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr><td colspan="5">Belum ada pelanggan lunas.</td></tr>
    <?php endif; ?>
</table>
</body>
</html><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/reports/excel.blade.php ENDPATH**/ ?>