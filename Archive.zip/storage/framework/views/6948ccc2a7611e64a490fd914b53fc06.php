<?php $__env->startSection('title', 'Konfirmasi Pembayaran'); ?>

<?php $__env->startPush('styles'); ?>
<style>.invoice-row.selected{ background:#e7f1ff; }</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <div>
        <h4 class="mb-0"><i class="bi bi-cash-coin"></i> Konfirmasi Pembayaran</h4>
        <p class="text-muted small mb-0"><?php echo e($customer->name); ?> &middot; <?php echo e($customer->customer_code); ?></p>
    </div>
    <a href="<?php echo e(route('scan.customer', $customer)); ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
</div>

<?php if(session('error')): ?>
<div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> <?php echo e(session('error')); ?></div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('scan.pay.store', $customer)); ?>" id="pay-form">
<?php echo csrf_field(); ?>
<input type="hidden" name="idempotency_key" value="<?php echo e($idempotencyKey); ?>">
<input type="hidden" name="payment_method" value="cash">

<div class="row g-3">
    <div class="col-md-7">
        <div class="card"><div class="card-header bg-white"><strong>Pilih Tagihan yang Dibayar</strong></div>
        <div class="card-body p-0">
        <?php if($invoices->isEmpty()): ?>
            <div class="p-4 text-center text-muted">Tidak ada tagihan aktif.</div>
        <?php else: ?>
            <div class="table-responsive">
            <table class="table table-sm align-middle mb-0">
            <thead class="table-light"><tr><th></th><th>Periode</th><th>Nominal</th><th>Sisa</th></tr></thead>
            <tbody>
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="invoice-row" data-balance="<?php echo e($inv->balance()); ?>" data-id="<?php echo e($inv->id); ?>">
                <td><input type="checkbox" name="invoices[]" value="<?php echo e($inv->id); ?>" class="form-check-input invoice-check" <?php echo e(in_array($inv->id, old('invoices', [])) ? 'checked' : ''); ?>></td>
                <td><?php echo e(format_period($inv->billing_period)); ?></td>
                <td><?php echo e(format_rupiah($inv->amount)); ?></td>
                <td class="text-danger"><?php echo e(format_rupiah($inv->balance())); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            </table>
            </div>
        <?php endif; ?>
        </div></div>
    </div>
    <div class="col-md-5">
        <div class="card mb-3"><div class="card-body">
            <div class="mb-3">
                <label class="form-label">Nominal Diterima (Rp) <span class="text-danger">*</span></label>
                <input type="number" name="amount_received" id="amount_received" class="form-control form-control-lg" value="<?php echo e(old('amount_received')); ?>" min="1" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Catatan</label>
                <textarea name="notes" class="form-control" rows="2"><?php echo e(old('notes')); ?></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Hasil Kunjungan</label>
                <select name="visit_result" class="form-select">
                    <option value="paid" <?php if(old('visit_result')==='paid'): echo 'selected'; endif; ?>>Berhasil menerima pembayaran</option>
                    <option value="not_home" <?php if(old('visit_result')==='not_home'): echo 'selected'; endif; ?>>Pelanggan tidak di rumah</option>
                    <option value="recall_requested" <?php if(old('visit_result')==='recall_requested'): echo 'selected'; endif; ?>>Minta kunjungan ulang</option>
                    <option value="cannot_pay" <?php if(old('visit_result')==='cannot_pay'): echo 'selected'; endif; ?>>Belum dapat membayar</option>
                    <option value="address_not_found" <?php if(old('visit_result')==='address_not_found'): echo 'selected'; endif; ?>>Alamat tidak ditemukan</option>
                    <option value="other" <?php if(old('visit_result')==='other'): echo 'selected'; endif; ?>>Kendala lain</option>
                </select>
            </div>
        </div></div>

        <div class="card"><div class="card-body">
            <dl class="row mb-0 small">
                <dt class="col-7">Total Sisa Dipilih</dt><dd class="col-5 text-end" id="selected-total">Rp0</dd>
                <dt class="col-7">Nominal Diterima</dt><dd class="col-7 text-end" id="received-display">Rp0</dd>
                <dt class="col-7">Status</dt><dd class="col-5 text-end"><span id="status-badge" class="badge bg-secondary">—</span></dd>
            </dl>
            <div id="warning" class="alert alert-danger py-2 small mt-2 d-none"></div>
            <button type="submit" class="btn btn-success btn-lg w-100 mt-2" id="submit-btn"><i class="bi bi-check-lg"></i> Konfirmasi Pembayaran</button>
        </div></div>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const checks = document.querySelectorAll('.invoice-check');
const amountInput = document.getElementById('amount_received');
const selectedTotal = document.getElementById('selected-total');
const receivedDisplay = document.getElementById('received-display');
const statusBadge = document.getElementById('status-badge');
const warning = document.getElementById('warning');
const submitBtn = document.getElementById('submit-btn');
const rows = document.querySelectorAll('.invoice-row');

function fmt(v){ return 'Rp'+Number(v||0).toLocaleString('id-ID'); }

function recalc(){
    let total=0;
    checks.forEach(c=>{
        const row=c.closest('.invoice-row');
        row.classList.toggle('selected', c.checked);
        if(c.checked) total += parseInt(row.dataset.balance,10);
    });
    selectedTotal.textContent = fmt(total);
    const received = parseInt(amountInput.value||0,10);
    receivedDisplay.textContent = fmt(received);
    if(received<=0){
        statusBadge.textContent='—'; statusBadge.className='badge bg-secondary';
        warning.classList.add('d-none'); submitBtn.disabled=false; return;
    }
    if(received > total){
        statusBadge.textContent='Kelebihan'; statusBadge.className='badge bg-danger';
        warning.textContent='Nominal melebihi sisa tagihan. Kelebihan bayar belum diizinkan.';
        warning.classList.remove('d-none'); submitBtn.disabled=true;
    } else if(received === total){
        statusBadge.textContent='Lunas'; statusBadge.className='badge bg-success';
        warning.classList.add('d-none'); submitBtn.disabled=false;
    } else {
        statusBadge.textContent='Sebagian'; statusBadge.className='badge bg-warning text-dark';
        warning.classList.add('d-none'); submitBtn.disabled=false;
    }
}
checks.forEach(c=>c.addEventListener('change', recalc));
amountInput.addEventListener('input', recalc);
recalc();

document.getElementById('pay-form').addEventListener('submit', function(e){
    const anyChecked = Array.from(checks).some(c=>c.checked);
    if(!anyChecked){ e.preventDefault(); alert('Pilih minimal satu tagihan.'); return; }
    if(parseInt(amountInput.value||0,10)<=0){ e.preventDefault(); alert('Nominal harus > 0.'); return; }
    submitBtn.disabled=true; submitBtn.innerHTML='<span class="spinner-border spinner-border-sm"></span> Memproses…';
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill-collector/resources/views/scan/pay.blade.php ENDPATH**/ ?>