<?php $__env->startSection('title', 'Data Dusun'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
    <h4 class="mb-0"><i class="bi bi-geo-alt"></i> Data Dusun</h4>
    <div class="btn-group">
        <a href="<?php echo e(route('customers.by-dusun')); ?>" class="btn btn-outline-secondary"><i class="bi bi-diagram-3"></i> Lihat per Dusun</a>
        <a href="<?php echo e(route('dusun.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Dusun</a>
    </div>
</div>
<div class="card">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light"><tr><th>Nama Dusun</th><th class="text-center">Jumlah Pelanggan</th><th>Catatan</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $dusun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><strong><?php echo e($d->name); ?></strong></td>
                    <td class="text-center">
                        <a href="<?php echo e(route('customers.index', ['dusun' => $d->name])); ?>" class="badge text-bg-primary text-decoration-none"><?php echo e($d->customers_count); ?> pelanggan</a>
                    </td>
                    <td><?php echo e($d->notes ?: '-'); ?></td>
                    <td class="text-end text-nowrap">
                        <a href="<?php echo e(route('dusun.edit', $d)); ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                        <form action="<?php echo e(route('dusun.destroy', $d)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Hapus dusun ini?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button></form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="text-center text-muted py-4">Belum ada dusun. <a href="<?php echo e(route('dusun.create')); ?>">Tambah dusun</a>.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($dusun->hasPages()): ?><div class="card-footer bg-white"><?php echo e($dusun->links()); ?></div><?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/dusun/index.blade.php ENDPATH**/ ?>