<div class="row g-3">
    <div class="col-md-6">
        <label class="form-label">Nama Dusun <span class="text-danger">*</span></label>
        <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name', $dusun->name ?? '')); ?>" required autofocus>
        <div class="form-text small">Nama dusun akan dipakai sebagai pilihan di form pelanggan.</div>
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-12">
        <label class="form-label">Catatan</label>
        <textarea name="notes" class="form-control" rows="2"><?php echo e(old('notes', $dusun->notes ?? '')); ?></textarea>
    </div>
    <div class="col-12">
        <button class="btn btn-primary"><i class="bi bi-check-lg"></i> Simpan</button>
        <a href="<?php echo e(route('dusun.index')); ?>" class="btn btn-outline-secondary">Batal</a>
    </div>
</div><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/dusun/_form.blade.php ENDPATH**/ ?>