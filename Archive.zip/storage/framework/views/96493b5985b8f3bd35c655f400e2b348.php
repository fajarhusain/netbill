<?php $__env->startSection('title', 'Penagihan per Dusun'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3 gap-2">
    <h5 class="mb-0"><i class="bi bi-diagram-3"></i> Penagihan per Dusun</h5>
    <a href="<?php echo e(route('blast.index')); ?>" class="btn btn-success btn-sm"><i class="bi bi-whatsapp"></i> Blast WA</a>
</div>

<div class="card bg-danger-subtle border-danger mb-3"><div class="card-body py-2">
    <div class="d-flex justify-content-between align-items-center">
        <div class="small"><i class="bi bi-exclamation-triangle"></i> Total Tunggakan Semua Dusun</div>
        <div class="fw-bold fs-5 text-danger"><?php echo e(format_rupiah($totalArrearsAll)); ?></div>
    </div>
</div></div>

<?php if($stats->isEmpty()): ?>
    <div class="card"><div class="card-body text-center text-muted py-5">
        <i class="bi bi-geo-alt fs-1 d-block mb-2 opacity-50"></i>
        Belum ada dusun terdaftar.
    </div></div>
<?php else: ?>
    <div class="row g-2">
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12 col-md-6">
            <a href="<?php echo e(route('collections.show', $s->id)); ?>" class="text-decoration-none">
                <div class="card stat-card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <div class="text-muted small"><i class="bi bi-geo-alt"></i> Dusun</div>
                                <div class="stat-value"><?php echo e($s->name); ?></div>
                            </div>
                            <?php if($s->total_arrears > 0): ?>
                            <span class="badge text-bg-danger"><?php echo e(format_rupiah($s->total_arrears)); ?></span>
                            <?php else: ?>
                            <span class="badge text-bg-success"><i class="bi bi-check-circle"></i> Lunas</span>
                            <?php endif; ?>
                        </div>
                        <div class="d-flex gap-2 mt-2 flex-wrap">
                            <span class="badge text-bg-primary"><?php echo e($s->total); ?> pelanggan</span>
                            <span class="badge text-bg-success"><?php echo e($s->active); ?> aktif</span>
                            <?php if($s->arrears_count > 0): ?>
                            <span class="badge text-bg-warning"><?php echo e($s->arrears_count); ?> menunggak</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/fajarhusainasyari/netbill/resources/views/collections/index.blade.php ENDPATH**/ ?>